import pathlib,json,yaml,hashlib,re,urllib.parse,shutil,datetime,zipfile,collections
out=pathlib.Path('/tmp/tekton-value-corpus-worker')
packet=out/'frozen-source-packet';packet.mkdir(exist_ok=True)
heads={x['repo']:x['sha'] for x in json.loads((out/'sampling-frame-heads.json').read_text())}
heads['tektoncd/catalog']='112374ce1262b133a77300bd8133445722605e04'
extra=json.loads((out/'integration-examples-resolution-pin.json').read_text());heads[extra['repo']]=extra['sha']
foreign={}
for f in ['foreign-task-sources.json','additional-foreign-task-sources.json']:
 for x in json.loads((out/f).read_text()):
  if 'error'not in x:foreign[(x['repo'],x['sha'],x['path'])]=x
hub={(x['catalog'],x['name'],x['requested_version']):x for x in json.loads((out/'hub-task-sources.json').read_text()) if 'error'not in x}
source_index={}
def save(src,dest,url,repo=None,sha=None,path=None):
 b=src.read_bytes();dest='source/'+dest
 p=packet/dest;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 r={'packet_path':dest,'url':url,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'repo':repo,'commit':sha,'original_path':path};source_index[dest]=r;return dest

def gitfile(repo,sha,path):
 if heads.get(repo)==sha and (out/'sources'/repo.replace('/','-')/path).is_file():src=out/'sources'/repo.replace('/','-')/path
 elif (repo,sha,path)in foreign:src=out/'foreign'/repo.replace('/','-')/sha/path
 else:return None
 url=f'https://github.com/{repo}/blob/{sha}/{path}'
 return save(src,f'{repo}/{sha}/{path}',url,repo,sha,path)

def taskdoc(path, expected_name=None):
 docs=[d for d in yaml.safe_load_all(path.read_text()) if isinstance(d,dict) and d.get('kind') in ['Task','ClusterTask']]
 matching=[d for d in docs if d.get('metadata',{}).get('name')==expected_name] if expected_name else []
 if matching:return matching[0]
 if len(docs)==1:return docs[0]
 raise ValueError('Ambiguous or missing Task document '+str(path)+' expected '+str(expected_name))

def pipeline(row):
 raw=out/'sources'/row['repo'].replace('/','-')/row['path'];docs=list(yaml.safe_load_all(raw.read_text()));doc=docs[row['document']];spec=doc['spec'] if doc.get('kind')=='Pipeline' else doc['spec']['pipelineSpec'];return raw,doc,spec

rows=json.loads((out/'preliminary-composition-frame.json').read_text())
ledger=[];eligible=[]
for row in rows:
 raw,doc,spec=pipeline(row);reason=[];bindings=[];run_bindings={};repo=row['repo'];sha=row['sha']
 if repo=='konflux-ci/tekton-integration-catalog' and '/0.3/'not in row['path']:reason.append('older version of deploy-fbc-operator family; latest 0.3 selected')
 params={x['name']:x.get('default') for x in spec.get('params',[])}
 for ordinal,t in enumerate(spec.get('tasks',[])+spec.get('finally',[])):
  phase='ordinary'if ordinal<len(spec.get('tasks',[]))else'finally';ref=t.get('taskRef');binding={'task_name':t['name'],'phase':phase,'ordinal':ordinal,'task_source_file':None}
  if not ref:
   if t.get('taskSpec'):binding.update(binding_method='embedded TaskSpec in original composition',task_spec=t['taskSpec'])
   else:reason.append(t['name']+': no TaskRef or TaskSpec')
  elif ref.get('resolver')=='git':
   ps={x['name']:x.get('value') for x in ref.get('params',[])};url=ps.get('url','');rev=ps.get('revision','');path=ps.get('pathInRepo','')
   if url=='$(params.taskGitUrl)':url=params.get('taskGitUrl','');run_bindings['taskGitUrl']=url
   r=urllib.parse.urlparse(url).path.strip('/').removesuffix('.git')
   if rev=='$(params.taskGitRevision)':rev=sha;run_bindings['taskGitRevision']=sha;method='caller-required Git revision fixed to same composition/source commit'
   elif rev.startswith('$(params.'):
    n=rev[len('$(params.'):-1];rev=params.get(n);run_bindings[n]=rev;method='declared default Git revision'
   elif rev in ['main','master']:rev=heads.get(r);method='mutable named branch frozen to observed source pin'
   else:method='literal committed Git revision'
   file=gitfile(r,rev,path)if rev else None
   if file:
    source=packet/file;obj=taskdoc(source,ref.get('name'));binding.update(binding_method=method,task_source_file=file,task_spec=obj.get('spec'),source_repo=r,source_commit=rev,source_path=path,original_task_ref=ref)
   else:reason.append(t['name']+': unresolved Git Task body '+url+'@'+str(rev)+':'+path)
  elif ref.get('resolver')=='hub':
   ps={x['name']:x.get('value') for x in ref.get('params',[])};h=hub.get((ps.get('catalog'),ps.get('name'),ps.get('version')))
   if h:
    src=out/h['path'];f=save(src,h['path'],h['url']);meta=save(src.parent/'metadata.json',str(src.parent.relative_to(out))+'/metadata.json',h['url']);obj=taskdoc(src,ps.get('name'));binding.update(binding_method='declared Hub version; captured published manifestRaw with digest',task_source_file=f,hub_metadata_file=meta,hub_package_version=h['package_version'],hub_requested_version=h['requested_version'],hub_digest=h['digest'],task_spec=obj.get('spec'),original_task_ref=ref)
   else:reason.append(t['name']+': unresolved Hub Task body')
  elif ref.get('resolver')=='bundles':reason.append(t['name']+': OCI bundle body not fetched; digest/name alone insufficient')
  else:reason.append(t['name']+': installed/name TaskRef has no frozen installation binding')
  bindings.append(binding)
 record={'pipeline_id':repo+':'+row['path']+':'+str(row['document']),'repo':repo,'commit':sha,'path':row['path'],'document':row['document'],'kind':doc.get('kind'),'name':doc.get('metadata',{}).get('name')or doc.get('metadata',{}).get('generateName'),'ordinary_task_count':len(spec.get('tasks',[])),'finally_task_count':len(spec.get('finally',[])),'selection_stage':'canonical path eligibility','eligibility':'excluded'if reason else'eligible-source-bodies','exclusion_reasons':reason,'source_body_resolution':not reason,'runtime_compatibility':'not evaluated','parameter_bindings_for_source_resolution':run_bindings,'resolved_tasks':bindings,'original_spec':spec,'spec_sha256':hashlib.sha256(json.dumps(spec,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'composition_file':gitfile(repo,sha,row['path'])}
 ledger.append(record)
 if not reason:eligible.append(record)

catalog=json.loads((out/'catalog-documentation-body-resolution.json').read_text())
for row in catalog:
 raw,doc,spec=pipeline(row);reason=[];bindings=[]
 if row['unresolved']:reason=['Task body lacks frozen documented installation binding: '+', '.join(x['task'] for x in row['unresolved'])]
 if row['family']=='task/generate-build-id':reason.append('build-service-api is a constant echo placeholder; no real application build')
 for b in row['task_body_bindings']:
  binding={'task_name':b['task'],'phase':'ordinary','binding_method':b['binding'],'task_source_file':None}
  t=next(t for t in spec.get('tasks',[])+spec.get('finally',[])if t['name']==b['task'])
  if 'path'in b:
   file=gitfile(row['repo'],row['sha'],b['path']);obj=taskdoc(packet/file,t.get('taskRef',{}).get('name'));binding.update(task_source_file=file,task_spec=obj.get('spec'),source_repo=row['repo'],source_commit=row['sha'],source_path=b['path'])
  else:binding['task_spec']=t['taskSpec']
  binding['ordinal']=list(spec.get('tasks',[])).index(t)if t in spec.get('tasks',[])else len(spec.get('tasks',[]))+list(spec.get('finally',[])).index(t);binding['phase']='ordinary'if t in spec.get('tasks',[])else'finally';bindings.append(binding)
 readme_path=row['family']+'/'+row['version']+'/README.md';readme=gitfile(row['repo'],row['sha'],readme_path)
 record={'pipeline_id':row['repo']+':'+row['path']+':'+str(row['document']),'repo':row['repo'],'commit':row['sha'],'path':row['path'],'document':row['document'],'kind':doc.get('kind'),'name':doc.get('metadata',{}).get('name')or doc.get('metadata',{}).get('generateName'),'ordinary_task_count':len(spec.get('tasks',[])),'finally_task_count':len(spec.get('finally',[])),'selection_stage':'one lexicographic composition at latest numerical family version','family':row['family'],'family_version':row['version'],'eligibility':'excluded'if reason else'eligible-source-bodies','exclusion_reasons':reason,'source_body_resolution':not reason,'runtime_compatibility':'not evaluated','parameter_bindings_for_source_resolution':{},'resolved_tasks':bindings,'original_spec':spec,'spec_sha256':hashlib.sha256(json.dumps(spec,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'composition_file':gitfile(row['repo'],row['sha'],row['path']),'documentation_file':readme}
 ledger.append(record)
 if not reason:eligible.append(record)

# Capture referenced StepAction bodies when their Git source binding is resolvable.
# This does not evaluate opaque image/helper behavior and does not change Task-body eligibility.
helper_ledger=[]
for r in eligible:
 pipeline_params={x['name']:x.get('default') for x in r['original_spec'].get('params',[])}
 pipeline_params.update(r['parameter_bindings_for_source_resolution'])
 for t in r['resolved_tasks']:
  original=next(x for x in r['original_spec'].get('tasks',[])+r['original_spec'].get('finally',[]) if x['name']==t['task_name'])
  task_params={x['name']:x.get('default')for x in t['task_spec'].get('params',[])}
  for x in original.get('params',[]):
   value=x.get('value')
   if isinstance(value,str) and value.startswith('$(params.') and value.endswith(')'):value=pipeline_params.get(value[9:-1],value)
   task_params[x['name']]=value
  t['referenced_stepactions']=[]
  for ordinal,st in enumerate(t['task_spec'].get('steps',[])):
   if not st.get('ref'):continue
   ref=st['ref'];record={'pipeline_id':r['pipeline_id'],'task_name':t['task_name'],'step_name':st.get('name'),'step_ordinal':ordinal,'original_ref':ref,'resolution':'unresolved; opaque boundary remains Unknown'}
   ps={x['name']:x.get('value')for x in ref.get('params',[])}
   for n,v in list(ps.items()):
    if isinstance(v,str) and v.startswith('$(params.') and v.endswith(')'):ps[n]=task_params.get(v[9:-1],v)
   repo=urllib.parse.urlparse(ps.get('url','')).path.strip('/').removesuffix('.git');rev=ps.get('revision');path=ps.get('pathInRepo')
   if rev in ['main','master','development']:rev=heads.get(repo)
   file=gitfile(repo,rev,path)if isinstance(path,str) and ref.get('resolver')=='git'else None
   if file:
    objects=[x for x in yaml.safe_load_all((packet/file).read_text())if isinstance(x,dict)and x.get('kind')=='StepAction']
    if len(objects)==1:record.update(resolution='resolved source body; runtime compatibility unevaluated',source_file=file,source_repo=repo,source_commit=rev,source_path=path,stepaction_spec=objects[0]['spec'])
   t['referenced_stepactions'].append(record);helper_ledger.append(record)

# Exact composition-spec duplicates collapse across the declared frame; task aliases/branch values are not rewritten.
clusters=collections.defaultdict(list)
for r in eligible:clusters[r['spec_sha256']].append(r)
dedup=[];duplicate_clusters=[]
for h,rs in clusters.items():
 rs.sort(key=lambda r:(r['repo'],r['path'],r['document']));dedup.append(rs[0]);
 if len(rs)>1:
  duplicate_clusters.append({'spec_sha256':h,'representative':rs[0]['pipeline_id'],'members':[x['pipeline_id']for x in rs]})
  for x in rs[1:]:x['eligibility']='excluded-duplicate';x['exclusion_reasons'].append('exact pipelineSpec duplicate of '+rs[0]['pipeline_id'])
dedup.sort(key=lambda r:(r['repo'],r['path'],r['document']));selected=dedup[:40]
for r in dedup[40:]:r['eligibility']='excluded-cap';r['exclusion_reasons'].append('beyond predeclared cap 40 in lexicographic repo/path order')
for i,r in enumerate(selected):r['sample_order']=i+1;r['eligibility']='selected-source-bodies'
freeze={'schema':'tekton-static-corpus-freeze-v1','frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':'before effect labels or expected recovery sets','scope':'static source composition and Task-body feasibility; no workload or operator study','cap':40,'sort':['repo','path','document'],'repository_pins':heads,'initial_candidate_pipeline_objects':264,'catalog_candidate_composition_objects':350,'canonical_candidates_before_task_resolution':len(ledger),'selected_count':len(selected),'stepaction_reference_occurrences':len(helper_ledger),'resolved_stepaction_occurrences':sum('source_file'in x for x in helper_ledger),'effect_labels':None,'expected_recovery_sets':None,'runtime_compatibility':'not evaluated','study_claim_limit':'No incident frequency, historical success, human/operator benefit, or acceptance verdict follows from this freeze.'}
for n,d in [('FREEZE.json',freeze),('selected-compositions.json',selected),('eligibility-ledger.json',ledger),('duplicate-clusters.json',duplicate_clusters),('SOURCE_INDEX.json',list(source_index.values())),('HELPER_SOURCE_LEDGER.json',helper_ledger)]:
 (packet/n).write_text(json.dumps(d,indent=2))
# Codebook schema only; records will be created separately by independent automated coders after freeze.
schema={'schema':'tekton-static-effect-coding-v1','unit':'task effect or prerequisite in a frozen selected composition','coder_role':'automated source coder; not a human participant','required_fields':['pipeline_id','task_name','phase','effect_or_precondition','state_item','source_file','source_lines','source_quote','confidence','opaque_boundary','warning_visibility_basis','backward_policy_expressibility_basis'],'allowed_confidence':['Source-explicit','Interface-supported','Unknown'],'prohibited_inferences':['successful historical recovery','task elapsed time without records','operator error/time','production frequency','hidden helper effects inferred solely from task names','sufficiency from a policy-selected set'],'no_prepopulated_effect_labels':True,'recovery_set_validation':'separate; source coding does not establish a complete correct repair'}
(packet/'CODING_SCHEMA.json').write_text(json.dumps(schema,indent=2));shutil.copyfile(__file__,packet/'freeze_frame.py')
# Preserve sampling-frame amendments and broad indexes so exclusions and version choice are reproducible.
for name in ['sampling-frame-heads.json','sampling-frame-resolved.json','sampling-frame-amendment-catalog.json','catalog-frame-resolved.json','preliminary-composition-frame.json','tektoncd-catalog-composition-index.json','catalog-latest-family-frame.json','catalog-documentation-body-resolution.json','foreign-task-sources.json','additional-foreign-task-sources.json','hub-task-sources.json']:
 shutil.copyfile(out/name,packet/name)
print(json.dumps(freeze,indent=2));print('Selected by repo',dict(collections.Counter(r['repo']for r in selected)));print('Unique source files',len(source_index));print('Excluded',dict(collections.Counter(r['eligibility']for r in ledger)))
for r in selected:print(r['sample_order'],r['pipeline_id'])

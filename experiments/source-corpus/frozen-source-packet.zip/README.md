# Frozen public Tekton source corpus

This packet freezes eligibility and source resolution before effect coding or expected recovery sets. The freeze contains 39 distinct composition bodies, 391 ordinary/finally Task occurrences, and 425 referenced StepAction occurrences. All Task and StepAction source bodies are retained. Runtime compatibility has not been evaluated; executable images and helper programs remain potential opaque boundaries.

## Sampling rules

The predefined repository frame consists of five public workflow repositories listed in FREEZE.json. It enumerated 264 standalone Pipeline objects. Before effect coding, a documented amendment added tektoncd/catalog at commit 112374ce1262b133a77300bd8133445722605e04 and covered standalone Pipelines plus embedded PipelineRun.spec.pipelineSpec; that enumeration contains 350 objects. These are a purposive source corpus, not a probability sample of Tekton deployments or incidents.

The first frame retains canonical pipelines/, release/pipelines/, and examples/ paths with at least two ordinary Tasks, excluding test/tests/testdata/fixtures/mocks/mock/integration-tests/prototypes path components. Catalog retains at least two ordinary Tasks, removes test/mock paths, chooses the latest numeric version per pipeline/task family, and chooses the lexicographically first composition file/document within that version. This produces 89 candidates for source resolution: 44 initial-frame and 45 Catalog families. BROAD_FRAME_LEDGER.json records all 614 enumerated objects and the earlier filtering stage; eligibility-ledger.json records each of the 89 source-resolution decisions.

Source-body eligibility requires every ordinary and finally TaskSpec to be embedded or resolved from a retained source file. Bare installed Task/ClusterTask names with no explicit installation binding and unfetched OCI Task bundles are excluded. Catalog README versioned paths, relative links, and explicit installation filenames supply documented bindings. A constant echo placeholder in the generate-build-id sample is excluded. Opaque effects of real helper programs are not a reason to infer effects or reject a retained source body.

Select one current numeric version per family, collapse exact canonical JSON pipelineSpec duplicates, then sort by repository/path/document and retain at most 40. The resulting frame has 39 bodies and no exact duplicates among selected compositions; the cap did not truncate it. PRESELECTION_DUPLICATE_CLUSTERS.json records two Catalog duplicate clusters among the 45 family candidates. RELATED_PROFILE_CLUSTERS.json records the three OpenShift ephemeral-cluster profiles as one related application family. Distinct bodies do not imply statistically independent applications; the 24 release-service compositions also share many Tasks and one repository.

## Retained sample

The sample has 24 release-service-catalog compositions, one tekton-integration-catalog composition, two KubeVirt Windows compositions, three OpenShift ephemeral-cluster profiles, and nine Catalog compositions. The complete sorted membership, original PipelineSpec, TaskSpecs, StepActionSpecs, source paths, binding methods, parameters, and hashes are in selected-compositions.json.

Release-service caller-required taskGitRevision is explicitly bound to the frozen composition/source commit for source resolution. This is a declared corpus binding, not evidence of an actual deployed PipelineRun or runtime default. Literal mutable branches are frozen to observed commits; the release-service development branch was checked and equals f067a17b8ebd91229e1b8bbb17bcd2e76f611dbb. All 425 StepAction references resolve under these same source bindings. Catalog git-rebase/0.2 documentation explicitly binds its sample to git-rebase/0.1; that historical documented version is retained, with compatibility unevaluated. KubeVirt Hub manifests were captured from ArtifactHub at the requested version; their SHA256 values equal the published package digests. No arbitrary latest version was substituted for an installed Task name.

## Files for two automated coders

Start with FREEZE.json, CODING_SCHEMA.json, selected-compositions.json, and SOURCE_INDEX.json. Retained raw composition, documentation, Task and StepAction files are under source/. HELPER_SOURCE_LEDGER.json maps every referenced StepAction occurrence to a source file. Keep each coder's labels in a new separate file after this freeze, preserving source quotes, line references, Unknown boundaries, and coder identity. Neither coder should claim to be a human participant.

The schema contains no effect labels or expected recovery sets. Source coding can describe explicitly evidenced state operations and the boundary of warning visibility and backward-policy expression. It cannot establish complete correct repair, incident frequency, historical recovery success, operator time/error, or a benefit over equally informed manual selection. No acceptance verdict follows from this freeze. No native workloads, project tests, production access, human study, or effect coding were performed.

## Integrity

All 291 raw-source file hashes were rechecked. Every selected composition has its full ordinary/finally Task occurrence count and a nonempty TaskSpec; every referenced StepAction has a retained source body. MANIFEST.sha256 covers every packet file except itself. The archive hash is supplied outside the archive to avoid self-reference.

import pathlib,json,hashlib,collections,shutil,zipfile,yaml
out=pathlib.Path('/tmp/tekton-value-corpus-worker');p=out/'frozen-source-packet'
freeze=json.loads((p/'FREEZE.json').read_text());selected=json.loads((p/'selected-compositions.json').read_text());ledger=json.loads((p/'eligibility-ledger.json').read_text());source=json.loads((p/'SOURCE_INDEX.json').read_text())
for x in source:assert hashlib.sha256((p/x['packet_path']).read_bytes()).hexdigest()==x['sha256']
for r in selected:
 assert len(r['resolved_tasks'])==r['ordinary_task_count']+r['finally_task_count']
 assert all(isinstance(t.get('task_spec'),dict) for t in r['resolved_tasks'])
 assert all('source_file'in h for t in r['resolved_tasks'] for h in t.get('referenced_stepactions',[]))
assert freeze['effect_labels'] is None and freeze['expected_recovery_sets'] is None
key=lambda r:(r['repo'],r['path'],r['document'])
canonical={key(r):r for r in ledger};broad=[]
for repo in json.loads((p/'sampling-frame-heads.json').read_text()):
 path=out/(repo['repo'].replace('/','-')+'-pipeline-index.json');rows=json.loads(path.read_text());shutil.copyfile(path,p/path.name)
 for row in rows:
  r=canonical.get(key(row));q=dict(row)
  q['frame_status']=r['eligibility'] if r else 'excluded before Task-body resolution'
  q['frame_reason']=r['exclusion_reasons'] if r else ['outside canonical pipelines/, release/pipelines/, examples/ paths; test/mock/prototype path; or fewer than two ordinary Tasks']
  broad.append(q)
catalog=json.loads((p/'tektoncd-catalog-composition-index.json').read_text());families=json.loads((p/'catalog-latest-family-frame.json').read_text())
for row in catalog:
 r=canonical.get(key(row));q=dict(row);q['frame_status']=r['eligibility']if r else'excluded before Task-body resolution';q['frame_reason']=r['exclusion_reasons']if r else['test/mock path; fewer than two ordinary Tasks; older family version; or nonlexicographic sample within chosen latest version'];broad.append(q)
(p/'BROAD_FRAME_LEDGER.json').write_text(json.dumps(broad,indent=2))
# Exact duplicate clusters in the Catalog family candidates, including excluded families.
clusters=collections.defaultdict(list)
for r in families:
 doc=list(yaml.safe_load_all((out/'sources'/r['repo'].replace('/','-')/r['path']).read_text()))[r['document']];spec=doc['spec']if doc['kind']=='Pipeline'else doc['spec']['pipelineSpec'];h=hashlib.sha256(json.dumps(spec,sort_keys=True,separators=(',',':')).encode()).hexdigest();clusters[h].append(r)
dups=[{'spec_sha256':h,'scope':'Catalog latest-version family candidates','members':[r['repo']+':'+r['path']+':'+str(r['document'])for r in rs]}for h,rs in clusters.items()if len(rs)>1]
(p/'PRESELECTION_DUPLICATE_CLUSTERS.json').write_text(json.dumps(dups,indent=2))
(p/'RELATED_PROFILE_CLUSTERS.json').write_text(json.dumps([{'cluster':'openshift ephemeral-cluster provisioning profiles','members':[r['pipeline_id']for r in selected if r['repo']=='openshift/konflux-tasks'],'interpretation':'Three distinct composition bodies for one related application family. Do not treat as independent deployments or independent random observations.'}],indent=2))
text='''# Frozen public Tekton source corpus

This packet freezes eligibility and source resolution before effect coding or expected recovery sets. The freeze contains 39 distinct composition bodies, 391 ordinary/finally Task occurrences, and 425 referenced StepAction occurrences. All Task and StepAction source bodies are retained. Runtime compatibility has not been evaluated; executable images and helper programs remain potential opaque boundaries.

## Sampling rules

The predefined repository frame consists of five public workflow repositories listed in FREEZE.json. It enumerated 264 standalone Pipeline objects. Before effect coding, a documented amendment added tektoncd/catalog at commit 112374ce1262b133a77300bd8133445722605e04 and covered standalone Pipelines plus embedded PipelineRun.spec.pipelineSpec; that enumeration contains 350 objects. These are a purposive source corpus, not a probability sample of Tekton deployments or incidents.

The first frame retains canonical pipelines/, release/pipelines/, and examples/ paths with at least two ordinary Tasks, excluding test/tests/testdata/fixtures/mocks/mock/integration-tests/prototypes path components. Catalog retains at least two ordinary Tasks, removes test/mock paths, chooses the latest numeric version per pipeline/task family, and chooses the lexicographically first composition file/document within that version. This produces 89 candidates for source resolution: 44 initial-frame and 45 Catalog families. BROAD_FRAME_LEDGER.json records all 614 enumerated objects and the earlier filtering stage; eligibility-ledger.json records each of the 89 source-resolution decisions.

Source-body eligibility requires every ordinary and finally TaskSpec to be embedded or resolved from a retained source file. Bare installed Task/ClusterTask names with no explicit installation binding and unfetched OCI Task bundles are excluded. Catalog README versioned paths, relative links, and explicit installation filenames supply documented bindings. A constant echo placeholder in the generate-build-id sample is excluded. Opaque effects of real helper programs are not a reason to infer effects or reject a retained source body.

Select one current numeric version per family, collapse exact canonical JSON pipelineSpec duplicates, then sort by repository/path/document and retain at most 40. The resulting frame has 39 bodies and no exact duplicates among selected compositions; the cap did not truncate it. PRESELECTION_DUPLICATE_CLUSTERS.json records two Catalog duplicate clusters among the 45 family candidates. RELATED_PROFILE_CLUSTERS.json records the three OpenShift ephemeral-cluster profiles as one related application family. Distinct bodies do not imply statistically independent applications; the 24 release-service compositions also share many Tasks and one repository.

## Retained sample

The sample has 24 release-service-catalog compositions, one tekton-integration-catalog composition, two KubeVirt Windows compositions, three OpenShift ephemeral-cluster profiles, and nine Catalog compositions. The complete sorted membership, original PipelineSpec, TaskSpecs, StepActionSpecs, source paths, binding methods, parameters, and hashes are in selected-compositions.json.

Release-service caller-required taskGitRevision is explicitly bound to the frozen composition/source commit for source resolution. This is a declared corpus binding, not evidence of an actual deployed PipelineRun or runtime default. Literal mutable branches are frozen to observed commits; the release-service development branch was checked and equals f067a17b8ebd91229e1b8bbb17bcd2e76f611dbb. All 425 StepAction references resolve under these same source bindings. Catalog git-rebase/0.2 documentation explicitly binds its sample to git-rebase/0.1; that historical documented version is retained, with compatibility unevaluated. KubeVirt Hub manifests were captured from ArtifactHub at the requested version; their SHA256 values equal the published package digests. No arbitrary latest version was substituted for an installed Task name.

## Files for two automated coders

Start with FREEZE.json, CODING_SCHEMA.json, selected-compositions.json, and SOURCE_INDEX.json. Retained raw composition, documentation, Task and StepAction files are under source/. HELPER_SOURCE_LEDGER.json maps every referenced StepAction occurrence to a source file. Keep each coder's labels in a new separate file after this freeze, preserving source quotes, line references, Unknown boundaries, and coder identity. Neither coder should claim to be a human participant.

The schema contains no effect labels or expected recovery sets. Source coding can describe explicitly evidenced state operations and the boundary of warning visibility and backward-policy expression. It cannot establish complete correct repair, incident frequency, historical recovery success, operator time/error, or a benefit over equally informed manual selection. No acceptance verdict follows from this freeze. No native workloads, project tests, production access, human study, or effect coding were performed.

## Integrity

All 291 raw-source file hashes were rechecked. Every selected composition has its full ordinary/finally Task occurrence count and a nonempty TaskSpec; every referenced StepAction has a retained source body. MANIFEST.sha256 covers every packet file except itself. The archive hash is supplied outside the archive to avoid self-reference.
'''
(p/'README.md').write_text(text)
shutil.copyfile(__file__,p/'finalize_freeze.py')
files=sorted(x for x in p.rglob('*')if x.is_file()and x.name!='MANIFEST.sha256')
(p/'MANIFEST.sha256').write_text(''.join(hashlib.sha256(x.read_bytes()).hexdigest()+'  '+str(x.relative_to(p))+'\n'for x in files))
z=out/'tekton-static-corpus-freeze.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED)as archive:
 for x in sorted(p.rglob('*')):
  if x.is_file():archive.write(x,str(x.relative_to(p)))
hashes={str(x.name):hashlib.sha256(x.read_bytes()).hexdigest()for x in [z,p/'FREEZE.json',p/'selected-compositions.json',p/'SOURCE_INDEX.json',p/'MANIFEST.sha256']};(out/'frozen-packet-hashes.json').write_text(json.dumps(hashes,indent=2));print(json.dumps(hashes,indent=2));print('Archive bytes',z.stat().st_size,'Broad objects',len(broad),'Preselection duplicate clusters',len(dups))

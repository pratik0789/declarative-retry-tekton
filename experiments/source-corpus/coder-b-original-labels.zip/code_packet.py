#!/usr/bin/env python3
"""Coder B's conservative frozen-source inventory, evidence extraction and labels.
No runtime execution, network access or policy inputs. Semantic claims are bounded.
"""
import collections, hashlib, json, pathlib, re, yaml

ROOT = pathlib.Path('/tmp/tekton-value-corpus-worker/frozen-source-packet')
OUT = pathlib.Path('/tmp/tekton-static-coder-b')
COMPS = json.loads((ROOT/'selected-compositions.json').read_text())
INDEX = {x['packet_path']: x for x in json.loads((ROOT/'SOURCE_INDEX.json').read_text())}
CACHE = {}

def mapget(node, key):
    if isinstance(node, yaml.MappingNode):
        for k, v in node.value:
            if k.value == key: return v
    return None

def evidence(file, node, limit=None):
    lines = CACHE[file]['lines']
    a, b = node.start_mark.line, node.end_mark.line
    if node.end_mark.column: b += 1
    b = max(a+1, b)
    if limit: b = min(b, a+limit)
    return {'source_file': file, 'source_lines': [a+1,b],
            'source_quote': '\n'.join(lines[a:b]),
            'source_sha256': INDEX[file]['sha256']}

def load(file):
    if file not in CACHE:
        text = (ROOT/file).read_text()
        CACHE[file] = {'lines':text.splitlines(),'docs':list(yaml.compose_all(text))}
    return CACHE[file]

def doc_for(file, kind, name):
    for d in load(file)['docs']:
        if not d: continue
        k=mapget(d,'kind'); m=mapget(d,'metadata'); n=mapget(m,'name')
        if k and n and k.value==kind and n.value==name: return d
    raise ValueError((file,kind,name))

def compnodes(c):
    d=doc_for(c['composition_file'],'Pipeline',c['name'])
    s=mapget(d,'spec'); out={}
    for phase,key in [('ordinary','tasks'),('finally','finally')]:
        seq=mapget(s,key)
        if seq:
            for n in seq.value:out[(phase,mapget(n,'name').value)]=n
    return out

def walk(n,path=()):
    yield path,n
    if isinstance(n,yaml.MappingNode):
        for k,v in n.value:yield from walk(v,path+(k.value,))
    elif isinstance(n,yaml.SequenceNode):
        for i,v in enumerate(n.value):yield from walk(v,path+(i,))

def features(file,node):
    """Finite literal operation inventory; not a shell interpreter or complete effect analysis."""
    out=[]
    patterns=[
      ('destructive local operation',r'\b(?:rm\s+-(?:rf|fr|f)|git\s+reset|git\s+push.*\s-f)\b'),
      ('local directory initialization',r'\bmkdir\s'),
      ('local content read or write',r'\b(?:cat\s|cp\s|tee\s)|\bopen\('),
      ('cluster API request',r'\b(?:oc|kubectl)\s+(?:-n\s+\S+\s+)?(?:create|apply|replace|patch|delete|get|wait|whoami|login)\b'),
      ('registry client request',r'\b(?:oras|skopeo|cosign)\s+(?:pull|push|copy|inspect|sign|verify|manifest)\b'),
      ('trust metadata initialization',r'\b(?:cosign\s+initialize|ec\s+sigstore\s+initialize)\b'),
      ('remote client invocation',r'\b(?:curl\s|git\s+(?:clone|pull|push)|hub\s+release\s+create|charon\s+upload|roxctl\s+central\s+m2m)'),
      ('result path write',r'(?:>|tee\s).*\$\((?:step\.)?results\.'),
      ('conditional execution or refusal',r'^\s*(?:if\s|elif\s|exit\s+[1-9])'),
      ('opaque sourced helper',r'^\s*(?:\.\s+|source\s+)'),
    ]
    lines=CACHE[file]['lines']; a=node.start_mark.line; b=node.end_mark.line
    for label,pat in patterns:
        for i in range(a,b):
            l=lines[i]
            if l.lstrip().startswith('#'):continue
            if label not in ['result path write','local content read or write'] and re.match(r'\s*(?:echo\b|echopid\b)',l):continue
            if re.search(pat,l):
                lo=max(a,i-1);hi=min(b,i+2)
                out.append({'class':label,'source_file':file,'source_lines':[lo+1,hi],
                  'source_quote':'\n'.join(lines[lo:hi]),'source_sha256':INDEX[file]['sha256'],
                  'confidence':'Unknown' if label=='opaque sourced helper' else 'Source-explicit',
                  'claim':'Literal source operation or guard; executes only if its branch/step is reached. External command behavior, atomicity and achieved outcome are not established.'})
                break
    return out

MODELS={}; coverage=[];effects=[];rels=[];graphs={}
for ci,c in enumerate(COMPS):
    cn=compnodes(c); names={t['name']:t for t in c['original_spec'].get('tasks',[])}
    g={n:set() for n in names}
    for n,t in names.items():
        for x in t.get('runAfter',[]):
            if x in g:g[x].add(n)
        for x in re.findall(r'\$\(tasks\.([^.)]+)\.results\.',json.dumps(t)):
            if x in g:g[x].add(n)
    def reachable(a,b):
        todo=[a];seen=set()
        while todo:
            x=todo.pop()
            if x==b:return True
            if x in seen:continue
            seen.add(x);todo.extend(g.get(x,()))
        return False
    graphs[c['pipeline_id']]={'edges':[[a,b] for a in g for b in sorted(g[a])]}
    for t in c['resolved_tasks']:
        file=t['task_source_file'] or c['composition_file']; phase=t['phase']; name=t['task_name']
        occ=cn[(phase,name)]
        if t['task_source_file']:
            d=next(d for d in load(file)['docs'] if d and mapget(d,'kind') and mapget(d,'kind').value=='Task')
            specnode=mapget(d,'spec');key=file
        else:specnode=mapget(occ,'taskSpec');key=file+'#'+name
        assert specnode is not None,(file,name)
        if key not in MODELS:
            model={'body_id':key,'source_file':file,'source_body_lines':evidence(file,specnode)['source_lines'],
              'inspection':'Structured YAML body inspection with focused script excerpts. Finite conservative labels; unlisted semantic effects are Unknown.',
              'description':None,'features':[],'helpers':[],'stepactions':[],'steps':[]}
            dn=mapget(specnode,'description')
            if dn and dn.value.strip():
                model['description']={'text':dn.value,**evidence(file,dn,8),'confidence':'Interface-supported',
                  'claim':'Declared Task interface only; runtime implementation and actual success are not independently resolved.'}
            sn=mapget(specnode,'steps')
            for j,st in enumerate(sn.value if sn else []):
                sd=t['task_spec'].get('steps',[])[j]; sc=mapget(st,'script')
                model['steps'].append({'name':sd.get('name'),'source_lines':evidence(file,st)['source_lines'],
                  'image':sd.get('image'),'command':sd.get('command'),'args':sd.get('args'),
                  'when':sd.get('when'),'onError':sd.get('onError'),
                  'script_lines':evidence(file,sc)['source_lines'] if sc else None})
                if sc:model['features'].extend(features(file,sc))
                im=mapget(st,'image');cmd=mapget(st,'command');ar=mapget(st,'args')
                boundary=im or cmd or ar
                if boundary:model['helpers'].append({'step_name':sd.get('name'),'image':sd.get('image'),
                  'command':sd.get('command'),'args':sd.get('args'),**evidence(file,boundary,3),
                  'confidence':'Unknown','claim':'Runtime image/entrypoint or invoked helper internals are outside frozen source resolution; no idempotence, identity retention, availability, atomicity or complete repair guarantee.'})
            # Secret mounts / environmental bindings are source-visible requirements, not oracle facts.
            for path,node in walk(specnode):
                if path and path[-1] in ['secretKeyRef','secret','persistentVolumeClaim']:
                    model['features'].append({'class':'declared credential or storage binding',**evidence(file,node,6),
                      'confidence':'Source-explicit','claim':'This binding is declared in the Task. Runtime object content, permissions and availability remain Unknown.'})
            MODELS[key]=model
        model=MODELS[key]
        sas=[]
        for sa in t['referenced_stepactions']:
            sf=sa['source_file']; sk=sf
            if sk not in MODELS:
                d=next(d for d in load(sf)['docs'] if d and mapget(d,'kind') and mapget(d,'kind').value=='StepAction')
                sp=mapget(d,'spec');dn=mapget(sp,'description');sc=mapget(sp,'script');im=mapget(sp,'image')
                MODELS[sk]={'body_id':sk,'source_file':sf,'source_body_lines':evidence(sf,sp)['source_lines'],
                  'inspection':'Structured StepAction body inspection; finite literal labels.',
                  'description':{'text':dn.value,**evidence(sf,dn,8),'confidence':'Interface-supported',
                    'claim':'Declared StepAction interface; opaque helper behavior is not validated.'} if dn else None,
                  'features':features(sf,sc) if sc else [],'helpers':[{'image':sa['stepaction_spec'].get('image'),
                    'command':sa['stepaction_spec'].get('command'),'args':sa['stepaction_spec'].get('args'),
                    **evidence(sf,im or sp,3),'confidence':'Unknown',
                    'claim':'Container/command and remote scripts may perform unresolved operations. Runtime implementation and outcome remain Unknown.'}],
                  'stepactions':[],'steps':[]}
            sas.append({'step_name':sa['step_name'],'step_ordinal':sa['step_ordinal'],
                'body_id':sk,'resolution':sa['resolution'],'original_ref':sa['original_ref']})
        cov={'pipeline_id':c['pipeline_id'],'composition_index':ci,'repo':c['repo'],'task_name':name,
             'phase':phase,'ordinal':t['ordinal'],'body_id':key,'coverage_status':'inspected with bounded semantic scope',
             'binding_method':t['binding_method'],'composition_evidence':evidence(c['composition_file'],occ,4),
             'stepaction_occurrences':sas,'runtime_compatibility':'Unknown',
             'remaining_unknown':'Unlisted effects, runtime helper internals, external state retention, permissions, atomicity, incident history and complete repair sufficiency.'}
        coverage.append(cov)
        for bodyid in [key]+[s['body_id'] for s in sas]:
            bm=MODELS[bodyid]
            records=[]
            if bm['description']:records.append(('declared interface',bm['description']))
            records.extend((f['class'],f) for f in bm['features'])
            records.extend(('opaque runtime boundary',h) for h in bm['helpers'])
            if not records:records.append(('unresolved semantics',{'source_file':file,**evidence(file,specnode,3),'confidence':'Unknown','claim':'No supported semantic effect label.'}))
            for cls,e in records:
                effects.append({'effect_id':'B-E%05d'%(len(effects)+1),'pipeline_id':c['pipeline_id'],
                 'task_name':name,'phase':phase,'body_id':bodyid,'effect_or_precondition':cls,
                 'state_item':e.get('text',e.get('claim','')),'source_file':e['source_file'],
                 'source_lines':e['source_lines'],'source_quote':e['source_quote'],'source_sha256':e['source_sha256'],
                 'confidence':e['confidence'],'opaque_boundary':e.get('claim'),
                 'warning_visibility_basis':'Unknown: single-body operation is not a dependency or concrete plan warning.',
                 'backward_policy_expressibility_basis':'Unknown: requires relationship-specific graph and identity assumptions.'})
    # Relationship records retain all result wiring, but wiring alone is not a recovery obligation.
    rts={t['task_name']:t for t in c['resolved_tasks']}
    original={t['name']:t for t in c['original_spec'].get('tasks',[])+c['original_spec'].get('finally',[])}
    for consumer,ct in original.items():
        rt=rts[consumer];phase=rt['phase']; node=cn[(phase,consumer)]
        refmap=collections.defaultdict(set)
        for producer,result in re.findall(r'\$\(tasks\.([^.)]+)\.results\.([^.)]+)\)',json.dumps(ct)):
            if producer in rts:refmap[producer].add(result)
        for producer,results in sorted(refmap.items()):
            pt=rts[producer];pf=pt['task_source_file'] or c['composition_file'];cf=rt['task_source_file'] or c['composition_file']
            pm=MODELS[pf if pt['task_source_file'] else pf+'#'+producer];cm=MODELS[cf if rt['task_source_file'] else cf+'#'+consumer]
            pn=cn[(pt['phase'],producer)]
            # Quote the exact scalar result binding, not the whole Task.
            matches=[n for p,n in walk(node) if isinstance(n,yaml.ScalarNode) and any('$(tasks.'+producer+'.results.'+x+')' in n.value for x in results)]
            ta=any('artifact' in x.lower() for x in results) and any('trusted-artifact' in x['body_id'] for x in next(x for x in coverage if x['pipeline_id']==c['pipeline_id'] and x['task_name']==consumer)['stepaction_occurrences'])
            rels.append({'relationship_id':'B-R%04d'%(len(rels)+1),'pipeline_id':c['pipeline_id'],
              'producer':producer,'consumer':consumer,'consumer_phase':phase,'state_item':sorted(results),
              'relation':'declared trusted-artifact result flow' if ta else 'explicit result-value wiring',
              'confidence':'Interface-supported' if ta else 'Unknown',
              'composition_evidence':[evidence(c['composition_file'],n) for n in matches],
              'producer_evidence':pm['description'] or evidence(pf,load(pf)['docs'][0],3),
              'consumer_evidence':cm['description'] or evidence(cf,node if cf==c['composition_file'] else load(cf)['docs'][0],3),
              'warning_visibility_basis':'explicit task-result reference',
              'backward_policy_expressibility_basis':'Unknown' if phase=='finally' or pt['phase']=='finally' else ('later descendant' if reachable(consumer,producer) else 'earlier/parallel'),
              'identity_and_branch_assumptions':{'producer_when':original[producer].get('when'),
                 'consumer_when':ct.get('when'),'same_binding':'The literal result substitution refers to this producer; object content and lifetime are not implied by the string.'},
              'old_state_unusable_trigger':'Hypothetical only: required artifact/object/content is absent, expired, overwritten or inaccessible. No incident observation.' if ta else 'Unknown: result wiring does not establish a lost-state failure mode.',
              'repair_candidate':producer if ta else None,
              'repair_necessity':'Conditional availability of a declared artifact input; rerunning its producer is one candidate, not proved necessary or sufficient.' if ta else 'Unknown',
              'complete_repair_sufficiency':'Unknown: replacement result publication, bindings, branch, identity, helper behavior and side effects must be resolved.',
              'native_warning_count':None})
    # Checkout-to-consumer content dependencies are supported by declared Task interfaces and bindings.
    for producer,pt in rts.items():
        pf=pt['task_source_file'];pm=MODELS.get(pf,{})
        if not pf or '/git-clone/' not in pf:continue
        outs={x.get('workspace') for x in original[producer].get('workspaces',[]) if x.get('name')=='output'}
        for consumer,ct in original.items():
            if consumer==producer:continue
            ins={x.get('workspace') for x in ct.get('workspaces',[]) if x.get('name')=='source'}
            shared=outs&ins
            if not shared:continue
            cf=rts[consumer]['task_source_file'];cm=MODELS[cf]
            rels.append({'relationship_id':'B-R%04d'%(len(rels)+1),'pipeline_id':c['pipeline_id'],
              'producer':producer,'consumer':consumer,'consumer_phase':rts[consumer]['phase'],
              'relation':'checkout content consumed through common Workspace','state_item':sorted(shared),
              'confidence':'Interface-supported','producer_evidence':pm['description'],'consumer_evidence':cm['description'],
              'composition_evidence':[evidence(c['composition_file'],mapget(cn[(rts[x]['phase'],x)],'workspaces'),6) for x in [producer,consumer]],
              'warning_visibility_basis':'common Workspace binding',
              'backward_policy_expressibility_basis':'later descendant' if reachable(consumer,producer) else 'earlier/parallel',
              'identity_and_branch_assumptions':{'producer_when':original[producer].get('when'),'consumer_when':ct.get('when'),
               'same_binding':'Same bound Workspace/subdirectory/revision must contain the checkout expected by the consumer.'},
              'old_state_unusable_trigger':'Hypothetical empty/deleted/different checkout in required Workspace, while saved producer result remains. Not an observed incident.',
              'repair_candidate':producer,'repair_necessity':'Restore required source content; replay clone is a candidate. Preserved equivalent content or another restore could satisfy the same interface.',
              'complete_repair_sufficiency':'Unknown: a mutable revision may resolve differently; consumer side effects, secrets and remote services are unvalidated.',
              'native_warning_count':None})

def write(name,obj):
    (OUT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
write('coverage.json',{'schema':'tekton-coder-b-coverage-v1','coder':'automated B','protocol_artifact':'1835202037493026',
 'packet_artifact':'2515033349270286','composition_count':len(COMPS),'task_occurrence_count':len(coverage),
 'stepaction_occurrence_count':sum(len(x['stepaction_occurrences']) for x in coverage),
 'unique_body_count':len(MODELS),'unique_source_file_count':len({x['source_file'] for x in MODELS.values()}),
 'composition_graphs':graphs,'bodies':list(MODELS.values()),'task_occurrences':coverage})
write('effects.json',{'schema':'tekton-static-effect-coding-v1','scope':'finite literal/interface labels; unlisted semantics Unknown','records':effects})
write('relationships.json',{'schema':'tekton-coder-b-relationships-v1','scope':'finite result flows and supported checkout content relationships; not exhaustive semantic dependency discovery','records':rels})
stats={'compositions':len(COMPS),'task_occurrences':len(coverage),'ordinary':sum(x['phase']=='ordinary' for x in coverage),
 'finally':sum(x['phase']=='finally' for x in coverage),'stepaction_occurrences':sum(len(x['stepaction_occurrences']) for x in coverage),
 'unique_bodies':len(MODELS),'unique_source_files':len({x['source_file'] for x in MODELS.values()}),
 'effects':len(effects),'effect_confidence':dict(collections.Counter(x['confidence'] for x in effects)),
 'effect_classes':dict(collections.Counter(x['effect_or_precondition'] for x in effects)),
 'relationships':len(rels),'relationship_confidence':dict(collections.Counter(x['confidence'] for x in rels)),
 'relationship_classes':dict(collections.Counter(x['relation'] for x in rels)),
 'visibility':dict(collections.Counter(x['warning_visibility_basis'] for x in rels)),
 'expressibility':dict(collections.Counter(x['backward_policy_expressibility_basis'] for x in rels)),
 'repos':dict(collections.Counter(c['repo'] for c in COMPS))}
write('counts.json',stats)
print(json.dumps(stats,indent=2))

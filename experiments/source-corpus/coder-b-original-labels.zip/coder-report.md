# Automated source coder B: original frozen-source labels

## Scope and provenance

These are coder B's original labels, produced before consulting coder A's labels or any adjudication. The prospective coding protocol is [artifact 1835202037493026](https://artifacts.internalmeta.com/a/1835202037493026). The frozen source packet is [artifact 2515033349270286](https://artifacts.internalmeta.com/a/2515033349270286); its ZIP SHA-256 is `850f0d0661bc09db94d92b1c5cde791b25e5f63516446c706ff71b5e77a99def`.

The coder is an automated agent assisting the paper's author, using the same model/system and parent session as the other coder. It inherited project and manuscript-example context, including the goal of strengthening the paper and previous review concerns. It therefore was **not fully blinded to the manuscript or externally independent**. No peer labels or manuscript recovery-policy labels were consulted during this coding pass. This is separately performed automated coding, not a human study or independent operational validation.

Only frozen YAML source was used for this pass. The initial verification matched all 291 indexed source-file hashes. No containers, PipelineRuns, tests, native workloads, remote scripts, or OCI images were executed or fetched. No repository or manuscript was edited and no participants were contacted.

## Coverage and method

`coverage.json` accounts for all 39 selected composition bodies, all 391 Task occurrences (359 ordinary and 32 finally), and all 425 referenced StepAction occurrences. The source was deduplicated into 106 external Task bodies, 10 inline Task bodies, and 9 StepAction bodies: 125 bodies in 120 files. The Task bodies occupy 111 source files, including five composition files containing inline Tasks.

Every body received structured YAML inspection; focused script excerpts and documentary interfaces were inspected once and linked back to every occurrence. The published extraction scripts preserve this process. This is bounded semantic coding, **not exhaustive discovery of every effect or a line-by-line expert audit**. Unlisted semantic behavior remains Unknown. Literal-command classification is deliberately narrower than a claim about achieved runtime effects: a visible `oc patch`, for example, establishes that the script requests a patch when reached, not that the controller performs the expected teardown.

`effects.json` contains 2,404 occurrence-expanded records: 495 Source-explicit literal-operation/binding records, 805 Interface-supported documentary interface records, and 1,104 Unknown boundaries. These are repeated records over shared bodies; they are not 2,404 distinct effects, incidents, or independently observed facts. Classes include local reads/writes and initialization, destructive local operations, credential/storage bindings, cluster/registry/client requests, result writes, trust metadata initialization, guards/refusals, and opaque helpers.

Each record retains a frozen file, inclusive line span, exact source quote and file hash. A static citation audit checked 6,303 quoted evidence occurrences across the deliverables with zero quote mismatches; Task/StepAction coverage totals and Task occurrence uniqueness also matched. This audit checks transcription and coverage, not semantic truth.

## Relationships and conditional recovery assumptions

`relationships.json` contains 635 bounded relationship records. Of these, 249 are Interface-supported and 386 are Unknown; none is presented as a fully verified repair obligation. There are 358 result-value wiring records whose recovery semantics remain Unknown. There are 257 candidate trusted-artifact flows; 24 were downgraded to Unknown because one side's publication/materialization interface was not resolved through the recorded StepAction bodies. Exact result wiring alone does not prove artifact availability, identity retention, or correct recovery.

Eight checkout-content relationships connect git-clone interfaces to consumers through a shared Workspace. The remaining curated cases concern an external registry image tag, three external cluster credential interfaces, three finally teardown interfaces, two conditional ConfigMap import identities, two conditional finally ConfigMap deletions, and a shared ACS authentication configuration. These are source-grounded **hypothetical failure conditions**, not failure histories.

The dependency-specific visibility labels are 621 explicit Task-result references, nine common Workspace bindings, and five external-state relationships without either representation of the particular state item. Four of those five external-state cases are Unknown because the remote ConfigMap manifests are absent; they must not be counted as confirmed hidden dependencies. The remaining image-tag case passes the image through equal pipeline parameters and ordering; the Tasks' common Workspace carries build/deployment files and does not establish registry retention. Its helper behavior and realized deployment outcome remain unvalidated. **No concrete zero-warning plan was produced**, so every `native_warning_count` is null.

Graph-based backward expressibility is earlier/parallel for 621 records and Unknown for 14, including finally-related cases. The graph uses explicit result references and `runAfter`, not lexical YAML order. These labels do not prove that a policy can express a complete repair under current planner/runtime restrictions. No later-descendant positive case was established in this bounded pass.

For every candidate, the required identity, binding, branch and retention assumptions are retained. Restoring valid state may satisfy an interface without rerunning the nominated producer; conversely, replaying a producer can create a new identity or digest and leave saved bindings stale. **Complete repair sufficiency remains Unknown throughout.** This packet does not privilege a policy over an equally informed manual selection or a compiled persisted rule set.

## Family limits and negative findings

The selected compositions come from five repositories: 24 release-service-catalog compositions, one tekton-integration-catalog composition, two KubeVirt compositions, three OpenShift ephemeral-cluster examples, and nine Tekton catalog compositions/samples. They are convenience-selected source examples from a few related families, not 39 independent deployments or a representative sample of incident prevalence. Shared Task and StepAction bodies create substantial dependence between composition counts.

The large release family delegates most operational semantics to Python modules in runtime images. Its trusted-artifact create/use interfaces do not establish complete retained artifacts, failure atomicity or recovery success; create is documented as a no-op under a skip marker. Its common finally cleanup deletes InternalRequests through an opaque module, not a source-proved deletion of every trusted artifact or data directory.

The rh-rpm-advisories composition includes an inline `fake-create-advisory` script that writes empty advisory URL results. The three OpenShift `run-test` examples perform credential/connectivity checks such as `oc whoami`; they are not consequential application test histories. KubeVirt helper binaries and fetched ConfigMap contents are opaque. The TIC deployment includes `/utils.sh` and dynamically fetched gather scripts; pinning their YAML invocation does not pin or resolve those scripts' contents. Some sample references are mutable in their original YAML even though this packet resolves a frozen source body.

Trust initialization and buildpack preparation occur inside whole Tasks. Retrying such a Task already repeats its initializer Steps; their presence alone does not establish an additional cross-Task recovery contract benefit. Most recorded artifact/result and checkout relationships already have visible result or Workspace wiring. These negative and uncertain cases are retained rather than forced into positive effect counts.

## What this evidence can support

The originals support reviewable source examples, a conservative taxonomy of interfaces/uncertainties, and later coder agreement/adjudication against exact quotes. They do not measure operator time/errors, repair quality, real failure incidence, policy value relative to equally informed persisted alternatives, or actual recovery correctness. They do not establish that the previous reviewers' Blocking contribution concern is resolved, and imply no acceptance score.

Files: `coverage.json`, `effects.json`, `relationships.json`, `counts.json`, `citation-audit.json`, the two extraction/case scripts, and `manifest.json`. Full file SHA-256 values are retained in the manifest.

#!/usr/bin/env python3
"""Source-grounded conditional cases and negative boundaries added by coder B.
Run after code_packet.py. No external inputs or peer labels.
"""
import collections, json, pathlib
R=pathlib.Path('/tmp/tekton-value-corpus-worker/frozen-source-packet')
O=pathlib.Path('/tmp/tekton-static-coder-b')
C=json.loads((R/'selected-compositions.json').read_text())
I={x['packet_path']:x for x in json.loads((R/'SOURCE_INDEX.json').read_text())}
cov=json.loads((O/'coverage.json').read_text()); bodies={b['body_id']:b for b in cov['bodies']}
data=json.loads((O/'relationships.json').read_text());rels=data['records']
def quote(file,needle,before=1,after=2):
    lines=(R/file).read_text().splitlines();hits=[i for i,l in enumerate(lines) if needle in l]
    assert hits,(file,needle)
    a=max(0,hits[0]-before);b=min(len(lines),hits[0]+after)
    return {'source_file':file,'source_lines':[a+1,b],'source_quote':'\n'.join(lines[a:b]),'source_sha256':I[file]['sha256']}
def taskfile(ci,name):
    t=next(t for t in C[ci]['resolved_tasks'] if t['task_name']==name)
    return t['task_source_file'] or C[ci]['composition_file']
def add(ci,producer,consumer,state,relation,confidence,vis,prod,cons,comp,assumption,trigger,repair,necessity,express='earlier/parallel'):
    rels.append({'relationship_id':'B-R%04d'%(len(rels)+1),'pipeline_id':C[ci]['pipeline_id'],
      'producer':producer,'consumer':consumer,'consumer_phase':next(t['phase'] for t in C[ci]['resolved_tasks'] if t['task_name']==consumer),
      'relation':relation,'state_item':state,'confidence':confidence,
      'producer_evidence':prod,'consumer_evidence':cons,'composition_evidence':comp,
      'warning_visibility_basis':vis,'backward_policy_expressibility_basis':express,
      'identity_and_branch_assumptions':assumption,'old_state_unusable_trigger':trigger,
      'repair_candidate':repair,'repair_necessity':necessity,
      'complete_repair_sufficiency':'Unknown: source interfaces alone do not resolve runtime helper semantics, external retention, credentials, replacement identities or side effects.',
      'native_warning_count':None})

# Trust-artifact flow labels need the actual publication/materialization interfaces,
# rather than treating a Task description or a result name as a validated oracle.
for rel in rels:
    if rel['relation']!='declared trusted-artifact result flow':continue
    p=next(x for x in cov['task_occurrences'] if x['pipeline_id']==rel['pipeline_id'] and x['task_name']==rel['producer'])
    c=next(x for x in cov['task_occurrences'] if x['pipeline_id']==rel['pipeline_id'] and x['task_name']==rel['consumer'])
    rel['producer_artifact_interfaces']=[bodies[s['body_id']]['description'] for s in p['stepaction_occurrences'] if 'create-trusted-artifact/' in s['body_id']]
    rel['consumer_artifact_interfaces']=[bodies[s['body_id']]['description'] for s in c['stepaction_occurrences'] if '/use-trusted-artifact' in s['body_id']]
    if not rel['producer_artifact_interfaces'] or not rel['consumer_artifact_interfaces']:
        rel['confidence']='Unknown';rel['repair_necessity']='Unknown: one side of publication/materialization interface is unresolved in this composition.'

# Image tag identity is an external dependency even though these Tasks also share
# a Workspace for unrelated build/deployment files.
ci=30;f=C[ci]['composition_file'];p=taskfile(ci,'kaniko');q=taskfile(ci,'gke-deploy')
add(ci,'kaniko','gke-deploy','$(params.imageUrl):$(params.imageTag)',
 'registry image tag passed through pipeline parameters','Interface-supported','external state without either',
 [quote(p,'--destination=$(params.IMAGE)')],[quote(q,'command: ["/gke-deploy"]')],
 [quote(f,'$(params.imageUrl):$(params.imageTag)'),quote(f,'--image=$(params.imageUrl):$(params.imageTag)')],
 'Same image URL/tag and registry; selected build/deploy arguments. Workspace sharing concerns source/manifests and does not prove registry retention. Tag mutability and pull behavior are Unknown.',
 'Hypothetical tag missing/overwritten/inaccessible when deployment or subsequent pod pull needs it; not an observed incident.',
 'kaniko','Publish an appropriate image or provide another valid retained image. Rebuilding under the same tag need not restore the original digest.')

# SecretRef is only a locator. Provider side is an explicit controller request;
# the controller's secret creation/retention behavior is outside this packet.
for ci in [27,28,29]:
    f=C[ci]['composition_file'];p=taskfile(ci,'provision-ephemeral-cluster');q=f
    secretparam='clusterCredentialsSecretRef' if ci==27 else 'kubeconfigSecretRef'
    add(ci,'provision-ephemeral-cluster','run-test','credential Secret and external test cluster',
      'cluster credential locator and readiness interface','Interface-supported','explicit task-result reference',
      [quote(p,'writeConnectionSecretToRef:',0,3),quote(p,'oc create -f testplatformcluster_claim.yaml')],
      [quote(q,'secretName:' if ci==28 else 'secretKeyRef:',0,4),quote(q,'oc whoami',0,1)],
      [quote(f,'name: '+secretparam,0,2)],
      'Controller successfully creates the named Secret and ready cluster; the consumer Secret key/binding remains valid. Controller implementation, resource retention and full credential lifecycle are unresolved.',
      'Hypothetical Secret/cluster absent, expired or torn down while the saved secretRef remains; not an observed failure.',
      'provision-ephemeral-cluster','Consumer needs working credentials/cluster. Reprovisioning is a candidate, but can change identities and saved references; an equally informed restore may suffice.')
    d=taskfile(ci,'deprovision-ephemeral-cluster')
    add(ci,'deprovision-ephemeral-cluster','run-test','earlier provisioned test cluster',
      'finally teardown may invalidate later recovery use','Interface-supported','explicit task-result reference',
      [quote(d,'oc -n "$NAMESPACE" patch',0,2),quote(d,'oc -n "$NAMESPACE" wait',0,2)],
      [quote(q,'oc whoami',0,1)],[quote(f,'- name: deprovision-ephemeral-cluster',0,3)],
      'This is a finally action; controller acts on teardown request and a subsequent recovery consumer still targets that cluster. Actual resource deletion/secret invalidation is Unknown.',
      'Hypothetical recovery after teardown completion; saved strings do not establish live credentials/cluster.',
      'provision-ephemeral-cluster','Restore a valid cluster and bindings, or refuse reuse. Whole retry protocol and finally-policy semantics are not derived here.',express='Unknown')

# ConfigMap relationship cannot be resolved fully: the fetched remote manifest
# is absent, so the identity match to the VM's named ConfigMap is conditional.
for ci,importer,urlparam,cmparam in [(25,'import-unattend-configmaps','unattendXMLConfigMapsURL','customizeConfigMapName'),(26,'import-autounattend-configmaps','autounattendXMLConfigMapsURL','autounattendConfigMapName')]:
    f=C[ci]['composition_file'];q=taskfile(ci,'create-vm');p=taskfile(ci,importer)
    add(ci,importer,'create-vm','sysprep ConfigMap',
      'remote ConfigMap manifest to VM sysprep name: conditional identity','Unknown','external state without either',
      [quote(f,'oc apply',1,2),quote(p,'$(params.SCRIPT)',0,1)],
      [quote(f,'configMap:',0,3),quote(q,'command:',0,3)],
      [quote(f,'name: $(params.'+cmparam+')',0,1)],
      'Fetched URL manifest actually creates the ConfigMap named by '+cmparam+' in the same namespace/cluster. Remote manifest content is not in the frozen packet; ConfigMap name/contents match is Unknown.',
      'Hypothetical named ConfigMap missing after finally deletion; depends on unresolved remote manifest identity.',
      importer,'VM manifest declares named sysprep ConfigMap. No unconditional producer necessity or complete repair can be inferred from an opaque remote manifest.')
    add(ci,'delete-imported-configmaps','create-vm','sysprep ConfigMap',
      'finally ConfigMap deletion: conditional identity','Unknown','external state without either',
      [quote(f,'oc delete -f $(params.'+urlparam+')',0,1)],
      [quote(f,'configMap:',0,3)],[],
      'Delete URL and previously applied URL are stable and identify the VM-referenced ConfigMap. Their content is unpinned and unavailable; deletion target match remains Unknown.',
      'Hypothetical retry needing ConfigMap after its deletion; not observed.',
      importer,'Restore ConfigMap content if identity and deletion assumptions hold; no complete repair proof.',express='Unknown')

# ACS setup is not passed as an exchange Task result: both use the same named
# workspace/config directory, with explicit runAfter ordering.
ci=23;f=C[ci]['composition_file'];p=taskfile(ci,'exchange-service-account-token');q=taskfile(ci,'run-collectors')
add(ci,'exchange-service-account-token','run-collectors','roxctl configuration in release Workspace',
 'persisted authentication configuration shared with collectors','Interface-supported','common Workspace binding',
 [quote(p,'roxctl central m2m exchange',0,5)],[quote(q,'ROX_CONFIG_DIR',0,4)],
 [quote(f,'- name: exchange-service-account-token',0,4),quote(f,'- exchange-service-account-token',1,2)],
 'hasCveCollector is true and the collector actually needs ACS auth; same roxConfigDir path and workspace. Collector scripts are cloned at runtime and their use/retention semantics are Unknown.',
 'Hypothetical lost/expired auth configuration when selected collector needs it; no incident observation.',
 'exchange-service-account-token','A valid configuration may be restored or token exchanged; actual collector necessity depends on unresolved runtime scripts and expiry.')

(O/'relationships.json').write_text(json.dumps(data,indent=2)+'\n')
s=json.loads((O/'counts.json').read_text());s.update({'relationships':len(rels),
 'relationship_confidence':dict(collections.Counter(x['confidence'] for x in rels)),
 'relationship_classes':dict(collections.Counter(x['relation'] for x in rels)),
 'visibility':dict(collections.Counter(x['warning_visibility_basis'] for x in rels)),
 'expressibility':dict(collections.Counter(x['backward_policy_expressibility_basis'] for x in rels))})
(O/'counts.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s,indent=2))

import hashlib,json,pathlib
P=pathlib.Path('/tmp/tekton-value-corpus-worker/frozen-source-packet');O=pathlib.Path('/tmp/tekton-static-adjudication');index=json.loads((P/'SOURCE_INDEX.json').read_text());lines={}
for r in index:
 raw=(P/r['packet_path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==r['sha256'];lines[r['packet_path']]=raw.decode().splitlines()
S=json.loads((P/'selected-compositions.json').read_text());expected={(r['pipeline_id'],t['task_name'],t['phase'])for r in S for t in r['resolved_tasks']};assert len(S)==39 and len(expected)==391
A=json.load(open('/tmp/tekton-static-coder-a/coverage.json'));ca={(r['pipeline_id'],t['task_name'],t['phase'])for r in A for t in r['task_occurrences']};B=json.load(open('/tmp/tekton-static-coder-b/coverage.json'));cb={(r['pipeline_id'],r['task_name'],r['phase'])for r in B['task_occurrences']};assert ca==cb==expected
count=0

def walk(x):
 global count
 if isinstance(x,dict):
  if 'source_file'in x and 'source_quote'in x and 'source_lines'in x:
   a,b=x['source_lines'];actual='\n'.join(lines[x['source_file']][a-1:b]);assert a>=1 and b>=a and x['source_quote'] in [actual,actual+'\n'],(x['source_file'],a,b);count+=1
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)
for p in [pathlib.Path('/tmp/tekton-static-coder-a/effects.json'),pathlib.Path('/tmp/tekton-static-coder-a/relationships.json'),pathlib.Path('/tmp/tekton-static-coder-b/effects.json'),pathlib.Path('/tmp/tekton-static-coder-b/relationships.json'),O/'adjudicated-relationships.json']:
 walk(json.loads(p.read_text()))
j=json.loads((O/'summary.json').read_text());assert j['common_coded_task_pairs']==sum(j['common_pair_support_status'].values());assert j['union_coded_task_pairs']==j['common_coded_task_pairs']+j['pairs_only_A']+j['pairs_only_B'];assert j['final_interface_supported_pairs']+j['final_unknown_pairs']==j['union_coded_task_pairs'];assert sum(j['supported_composition_repo_counts'].values())==j['compositions_with_supported_conditional_prerequisites'];assert sum(j['supported_visibility'].values())==j['final_interface_supported_pairs']
report={'raw_source_files_hash_verified':len(index),'compositions':len(S),'task_occurrences_in_both_coverages':len(expected),'exact_source_quotes_checked':count,'mismatches':0,'scope':'Checks source identities, occurrence coverage, literal quotation integrity (one optional terminal newline) and arithmetic. Does not validate runtime semantics, complete recovery, operator value or source-coding exhaustiveness.'};(O/'audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

import collections, hashlib, json, pathlib, re
P=pathlib.Path('/tmp/tekton-value-corpus-worker/frozen-source-packet');O=pathlib.Path('/tmp/tekton-static-adjudication')
A=json.load(open('/tmp/tekton-static-coder-a/relationships.json'));B=json.load(open('/tmp/tekton-static-coder-b/relationships.json'))['records'];S=json.loads((P/'selected-compositions.json').read_text());si={r['pipeline_id']:r for r in S}
key=lambda r:(r['pipeline_id'],r['producer'],r['consumer'])
a=collections.defaultdict(list);b=collections.defaultdict(list)
for r in A:a[key(r)].append(r)
for r in B:b[key(r)].append(r)
ak=set(a);bk=set(b);common=ak&bk;tab=collections.Counter((any(r['confidence']!='Unknown' for r in a[k]),any(r['confidence']!='Unknown' for r in b[k]))for k in common)
rows=[];decisions=[]
for k in sorted(set(a)|set(b)):
 aa=[r for r in a[k] if r['confidence']!='Unknown'];bb=[r for r in b[k] if r['confidence']!='Unknown']
 exemplar=(bb or b[k] or aa or a[k])[0];supported=bool(aa or bb)
 rationale='Both original coders support an interface-level conditional prerequisite.' if aa and bb else 'No original coder establishes a conditional reuse prerequisite; semantics remain Unknown.'
 extra=[]
 if supported and not aa and exemplar.get('relation')=='declared trusted-artifact result flow':
  comp=si[k[0]];ct=next(t for t in comp['resolved_tasks'] if t['task_name']==k[2]);pt=next(t for t in comp['resolved_tasks'] if t['task_name']==k[1]);orig=next(t for t in comp['original_spec']['tasks']+comp['original_spec'].get('finally',[])if t['name']==k[2])
  pars=[p for p in orig.get('params',[])if p['name']=='resultArtifacts'];assert pars and ('$(tasks.'+k[1]+'.results.sourceDataArtifact)')in json.dumps(pars),k
  helpers=[h for h in ct.get('referenced_stepactions',[])if 'extracts an array of Trusted Artifacts'in h['stepaction_spec'].get('description','')];assert helpers,k
  assert any(p.get('name')=='sourceDataArtifacts' and p.get('value')=='$(params.resultArtifacts)' for st in ct['task_spec']['steps'] for p in st.get('params',[])),k
  assert any(p['name']=='sourceDataArtifact' and 'artifact'in p.get('description','').lower() for p in pt['task_spec'].get('results',[])),k
  extra=[h['source_file'] for h in helpers]+[ct['task_source_file'],pt['task_source_file']]
  rationale='A omitted the array extractor. Frozen producer declares a trusted artifact result; the Pipeline binds it into resultArtifacts; consumer passes that array to the declared Trusted Artifact array extractor. Conditional payload availability is Interface-supported. Optional/no-op branches and image/module semantics remain Unknown.'
 if exemplar.get('relation')=='registry image tag passed through pipeline parameters':
  comp=si[k[0]];by={t['name']:t for t in comp['original_spec']['tasks']};ws=lambda t:{w['workspace'] for w in t.get('workspaces',[])}
  assert ws(by[k[1]])&ws(by[k[2]]),k
  exemplar=dict(exemplar);exemplar['warning_visibility_basis']='common Workspace binding';exemplar['state_carrier']='external registry; same URL/tag, conditional resolve/pull contract'
  rationale='Same IMAGE/--image URL/tag supports a conditional intended-image prerequisite. The task endpoints also share a Workspace, so structural visibility is common Workspace; registry state remains an external carrier. Unconditional command completion needing a live registry object is not established.'
 if exemplar.get('relation')=='finally teardown may invalidate later recovery use':
  exemplar=dict(exemplar);exemplar['warning_visibility_basis']='ordering only; shared upstream result-identified cluster, no direct result reference from invalidator to consumer'
  rationale='Frozen teardown Task declares cluster deprovisioning and patches tearDownCluster before waiting for controller completion; run-test consumes the cluster credential. This supports conditional lifecycle invalidation, not observed deletion. Invalidator is a finally Task; source-run ordering is distinct from a later recovery. The nominated repair is provision, not rerunning teardown. Full recovery validity/expressibility remains Unknown.'
 if exemplar.get('relation')=='persisted authentication configuration shared with collectors':
  rationale='Frozen exchange Task sets ROX_CONFIG_DIR on the data Workspace and invokes ACS token exchange; collector Task sets/exports the same directory for its declared CVE/fixed-CVE branch. Shared authentication interface is conditional on a collector needing that configuration. Dynamically fetched collector code and runtime credential semantics remain Unknown; no complete repair is established.'
 row={'pipeline_id':k[0],'producer':k[1],'consumer':k[2],'original_A_ids':[r['relationship_id']for r in a[k]],'original_B_ids':[r['relationship_id']for r in b[k]],'A_support':bool(aa)if k in ak else None,'B_support':bool(bb)if k in bk else None,'confidence':'Interface-supported'if supported else'Unknown','kind':exemplar.get('relation',exemplar.get('relationship_kind')),'structural_visibility':exemplar.get('warning_visibility_basis',exemplar.get('structural_visibility')),'record':exemplar,'additional_source_files':extra,'adjudication':rationale,'complete_repair_validity':'Unknown','actual_zero_warning_claim':None}
 rows.append(row)
 if bool(aa)!=bool(bb) or len(a[k])!=len(b[k]) or exemplar.get('relation') in ['registry image tag passed through pipeline parameters','finally teardown may invalidate later recovery use']:decisions.append(row)
supported=[r for r in rows if r['confidence']!='Unknown'];comps={r['pipeline_id']for r in supported};repo=collections.Counter(si[c]['repo']for c in comps)
stats={'composition_count':39,'task_occurrences':391,'finally_occurrences':32,'StepAction_occurrences':425,'common_coded_task_pairs':len(common),'union_coded_task_pairs':len(rows),'pairs_only_A':len(ak-bk),'pairs_only_B':len(bk-ak),'common_pair_support_status':{'both_support':tab[True,True],'A_only_support':tab[True,False],'B_only_support':tab[False,True],'neither_support':tab[False,False]},'common_support_status_agreement':tab[True,True]+tab[False,False],'final_interface_supported_pairs':len(supported),'final_unknown_pairs':len(rows)-len(supported),'compositions_with_supported_conditional_prerequisites':len(comps),'supported_composition_repo_counts':dict(sorted(repo.items())),'supported_visibility':dict(collections.Counter(r['structural_visibility']for r in supported)),'supported_kinds':dict(collections.Counter(r['kind']for r in supported)),'warning_free_supported_relationships_measured':None,'complete_valid_repairs_measured':None,'operators_measured':0,'observed_failure_histories':0,'scope':'Post-coding descriptive normalization to ordered Task pairs. Missing coder rows stay distinct from Unknown. Agreement is binary source-support status, not full event/effect/timing or semantic-validity agreement. Convenience/source family dependence and inherited project/model context apply.'}
for name,data in [('adjudicated-relationships.json',rows),('adjudication-decisions.json',decisions),('summary.json',stats)]: (O/name).write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(stats,indent=2))

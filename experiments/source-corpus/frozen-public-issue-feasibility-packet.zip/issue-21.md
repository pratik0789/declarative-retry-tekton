# Expected Behavior

Works

# Actual Behavior

Get the error

```
{"level":"fatal","ts":1601669955.6276362,"caller":"git-init/main.go:53","msg":"Error fetching git repository: error checking for known_hosts file: open /root/.ssh/known_hosts: too many levels of symbolic links","stacktrace":"main.main\n\tgithub.com/tektoncd/pipeline/cmd/git-init/main.go:53\nruntime.main\n\truntime/proc.go:203"}
```

# Additional Info

Running Pipelines 0.16.3, w/ flags. Same w/ 0.15.2 and 0.14.3. 

```
  disable-affinity-assistant: "false"
  disable-home-env-overwrite: "true"
  disable-working-directory-overwrite: "true"
  running-in-environment-with-injected-sidecars: "false"
```

I've been using `git-clone:0.1` for several months with 0.14.3 and 0.15.2 and, recently re-applied "0.1" and now I get the error above..

In my pipeline:
```
      #---------------------
      # git clone app
      #---------------------
    - name: git-clone-app-source
      taskRef:
        name: git-clone
      workspaces:
        - name: output
          workspace: scratch
      params:
        - name: url
          value: $(params.gitCloneUrl)
        - name: revision
          value: $(params.appTag)
```

The `gitCloneUrl` above is just a github project.

I see there were some changes to `0.1` over the past few months, but shouldn't this be stable? Last time it was installed was likely early/mid august for me. Now on re-installing after a pull I get this behavior.

Running this example: https://github.com/bitsofinfo/cicdstatemgr/tree/master/examples/tekton

https://github.com/bitsofinfo/cicdstatemgr/blob/31b65293fbce39bf69c060ce553b2400d30b56c6/examples/tekton/core/install.sh#L46
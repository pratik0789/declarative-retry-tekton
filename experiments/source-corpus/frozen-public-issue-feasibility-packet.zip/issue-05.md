# Expected Behavior

`timeouts.tasks` is documented as "the timeout for the cumulative time taken by non-`finally` Tasks specified in `pipeline.spec.tasks`" ([docs/pipelineruns.md](https://github.com/tektoncd/pipeline/blob/main/docs/pipelineruns.md#configuring-a-failure-timeout)). The `finally` phase has its own budget, `timeouts.finally`.

So a PipelineRun whose non-`finally` Tasks all complete inside `timeouts.tasks` should never be failed with the tasks timeout, regardless of how long the `finally` Tasks take afterwards.

# Actual Behavior

The tasks timeout keeps counting while the `finally` phase runs, so the elapsed time it measures is the whole PipelineRun, not the DAG phase.

[`HaveTasksTimedOut`](https://github.com/tektoncd/pipeline/blob/db251bd37727606489ea2b4038df384f526ad747/pkg/apis/pipeline/v1/pipelinerun_types.go#L216-L230) measures plain wall-clock time from `status.StartTime` and never stops:

```go
func (pr *PipelineRun) HaveTasksTimedOut(ctx context.Context, c clock.PassiveClock) bool {
	timeout := pr.TasksTimeout()
	startTime := pr.Status.StartTime

	if !startTime.IsZero() && timeout != nil {
		if timeout.Duration == config.NoTimeoutDuration {
			return false
		}
		runtime := c.Since(startTime.Time)   // <-- keeps growing during the finally phase
		if runtime > timeout.Duration {
			return true
		}
	}
	return false
}
```

Once the DAG has completed, that value keeps growing while `finally` Tasks run. As soon as it crosses `timeouts.tasks`, `GetPipelineConditionStatus` fails the PipelineRun with:

```
PipelineRun "tasks-timeout-leaks-into-finally" failed due to tasks failed to finish within "2m0s"
```

even though the DAG finished well inside those 2 minutes and the `finally` phase stayed inside its own `timeouts.finally`.

# Steps to Reproduce the Problem

1. Apply the PipelineRun below. The DAG task sleeps 30s (inside `timeouts.tasks: 2m`); the `finally` task sleeps 180s (inside `timeouts.finally: 5m`); the whole run takes ~3.5m (inside `timeouts.pipeline: 10m`). Every budget is respected.

```yaml
apiVersion: tekton.dev/v1
kind: PipelineRun
metadata:
  name: tasks-timeout-leaks-into-finally
spec:
  timeouts:
    pipeline: 10m
    tasks: 2m
    finally: 5m
  pipelineSpec:
    tasks:
      - name: quick-dag-task
        taskSpec:
          steps:
            - name: sleep
              image: mirror.gcr.io/alpine
              script: sleep 30
    finally:
      - name: slow-finally-task
        taskSpec:
          steps:
            - name: sleep
              image: mirror.gcr.io/alpine
              script: sleep 180
```

2. Watch the PipelineRun. About 2 minutes in — while the `finally` task is still running — the reason flips to `PipelineRunTimeoutRunningFinally`.
3. When the `finally` task completes, the PipelineRun ends as `Failed` with `PipelineRun "tasks-timeout-leaks-into-finally" failed due to tasks failed to finish within "2m0s"`.

Expected: `Succeeded`. Both Tasks ran to completion and no configured timeout was actually exceeded.

# Additional Info

- Kubernetes version: `v1.34.5`
- Tekton Pipeline version: `v1.12.2`; the code path is unchanged on `main` (`db251bd37727606489ea2b4038df384f526ad747`)
- `HaveTasksTimedOut` has measured plain wall-clock time from `status.StartTime` since it was introduced in `58fd07c23` ("Switch PipelineRun timeout -> TaskRun logic to instead signal the TaskRuns to stop", 2022-08-18), first released in **v0.40.0**. The implementation is byte-identical from v0.40.0 through v1.15.0 and `main`, so every release in that range is affected.
- Related but distinct: #8982 / #9709 are about `finally` Tasks not getting a chance to run when the tasks timeout is *genuinely* exceeded. #9709 fixed that by keeping the PipelineRun running until `finally` completes. This issue is the opposite direction: the tasks timeout is reported as exceeded when it never was, because the finally phase's own duration is being charged to it.

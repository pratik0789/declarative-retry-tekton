# Expected Behavior

Tekton Task `buildah` builds Dockerfile and pushes to designated registry.

# Actual Behavior

Build fails when using buildah task. Failure does not happen when using same buildah image and executing same command.

# Steps to Reproduce the Problem

1. Create TaskRun
```yaml
apiVersion: tekton.dev/v1beta1
kind: TaskRun
metadata:
  name: buildah-test
spec:
  taskRef:
    name: buildah
  serviceAccountName: build-bot # used to access gitlab repository
  params:
  - name: IMAGE
    value: xxxx
  - name: BUILDER_IMAGE
    value: quay.io/buildah/stable:v1.21.0
  workspaces:
  - name: source
    persistentVolumeClaim:
      claimName: workspace
    subPath: source
```
Obs.: The Dockerfile follows bellow:

```
FROM open-liberty:21.0.0.5-full-java11-openj9
COPY --chown=1001:0 src/main/liberty/config/server.xml /config/
COPY --chown=1001:0 target/*.war /config/dropins/
RUN bash -x configure.sh
```
2. kubectl -f apply buildah-test.yaml

3. Get logs: 
```
tkn -n tekton-pipelines tr logs -f buildah-test
```
```
[build] + [[ false == \t\r\u\e ]]
[build] + buildah --storage-driver=overlay bud --format=oci --tls-verify=false --no-cache -f ./Dockerfile -t xxxxx .
[build] STEP 1: FROM open-liberty:21.0.0.5-full-java11-openj9
[build] Trying to pull open-liberty:21.0.0.5-full-java11-openj9...
[build] Getting image source signatures
[build] Copying blob sha256:e0325c0a145505b130f0b59d434b117fb563d9c548b8f903b5e99c04613dd968
[build] Copying blob sha256:592ec2d7c1370aca6ef48ee1d20fbb3a4c148db400adc5dc575778c681f5dba0
[build] Copying blob sha256:345e3491a907bb7c6f1bdddcf4a94284b8b6ddd77eb7d93f09432b17b20f2bbe
[build] Copying blob sha256:f02e5b72a97b9662ca14cd3ef1e0da144d7824aaa94c1aac47bccb4b2df2623c
[build] Copying blob sha256:57671312ef6fdbecf340e5fed0fb0863350cd806c92b1fdd7978adbd02afc5c3
[build] Copying blob sha256:5e9250ddb7d0fa6d13302c7c3e6a0aa40390e42424caed1e5289077ee4054709
[build] Copying blob sha256:e8ff8c6e2f9089e3840f06d445d102f5657866b9d5d27c17f8a934c947abb1a3
[build] Copying blob sha256:4038aaea0da3f8fd905e57d509622a6601826c1fd17277c45d2c98bfb2890c49
[build] Copying blob sha256:cc65e528164e140507a46ad62bd3c847e96ab01a44cc97c3e8a98886f6252dde
[build] Copying blob sha256:61242350903954a339dd53967fb9d265cff8c4886ec92ea941fa8eeaf2002f3c
[build] Copying blob sha256:2d9f0985f6091a48c49d6cafaf702e18d42a68f492f38d63096f6947beaf42e5
[build] Copying blob sha256:f1e48d76130da7ba63ba78a21d83aa7cceb2642c9c40174a7619a17cb255ca93
[build] Copying config sha256:b9dcdbb0b64ce05a3121f9d9f374ca66668eca955e5ab5437d448bb2d08ea12d
[build] Writing manifest to image destination
[build] Storing signatures


[build] STEP 2: COPY --chown=1001:0 src/main/liberty/config/server.xml /config/
[build] STEP 3: COPY --chown=1001:0 target/*.war /config/dropins/
[build] STEP 4: RUN bash -x configure.sh
[build] + '[' '' '!=' true ']'
[build] + exec
[build] subprocess exited with status 21
[build] subprocess exited with status 21
[build] error building at STEP "RUN bash -x configure.sh": exit status 21

[push] 2021/06/11 19:32:05 Skipping step because a previous step failed

container step-push has failed  : [{"key":"StartedAt","value":"2021-06-11T19:32:05.798Z","type":"InternalTektonResult"}]
```

Full `configure.sh` script can be found here: [https://github.com/OpenLiberty/ci.docker/blob/master/releases/21.0.0.6/full/helpers/build/configure.sh](https://github.com/OpenLiberty/ci.docker/blob/master/releases/21.0.0.6/full/helpers/build/configure.sh)

# Additional Info

If I start a Pod with the same buildah image informed as BUILDER_IMAGE and execute the same command from tasks, it builds correctly.

```
apiVersion: apps/v1
kind: Deployment
metadata:
  name: buildah
  labels:
    component: buildah
spec:
  replicas: 1
  selector:
    matchLabels:
      component: buildah
  template:
    metadata:
      labels:
        component: buildah
    spec:
      containers:
      - name: buildah
        image: quay.io/buildah/stable:v1.21.0
        command:
        - sleep
        args:
        - "10000"
        securityContext:
          privileged: true
        resources:
          limits:
            memory: 256Mi
            cpu: 1000m
          requests:
            memory: 128Mi
            cpu: 100m
        volumeMounts:
        - name: workspace
          mountPath: /workspace
        - name: varlibcontainers
          mountPath: /var/lib/containers
      volumes:
      - name: workspace
        persistentVolumeClaim:
          claimName: workspace
      - name: varlibcontainers
        emptyDir: {}
```

```
kubectl -n tekton-pipelines exec -it buildah-598789d65-wmwl2 -- /bin/bash
```
```
[root@buildah-598789d65-wmwl2 /]#
[root@buildah-598789d65-wmwl2 /]#
[root@buildah-598789d65-wmwl2 /]# cd /workspace/source
[root@buildah-598789d65-wmwl2 source]# buildah --storage-driver=overlay bud --format=oci --tls-verify=false --no-cache -f ./Dockerfile -t xxxx .
STEP 1: FROM open-liberty:21.0.0.5-full-java11-openj9
Trying to pull open-liberty:21.0.0.5-full-java11-openj9...
Getting image source signatures
Copying blob 57671312ef6f done
Copying blob e0325c0a1455 done
Copying blob 345e3491a907 done
Copying blob 5e9250ddb7d0 done
Copying blob 592ec2d7c137 done
Copying blob f02e5b72a97b done
Copying blob e8ff8c6e2f90 done
Copying blob 4038aaea0da3 done
Copying blob cc65e528164e done
Copying blob 612423509039 done
Copying blob 2d9f0985f609 done
Copying blob f1e48d76130d done
Copying config b9dcdbb0b6 done
Writing manifest to image destination
Storing signatures
STEP 2: COPY --chown=1001:0 src/main/liberty/config/server.xml /config/
STEP 3: COPY --chown=1001:0 target/*.war /config/dropins/
STEP 4: RUN bash -x configure.sh
+ '[' '' '!=' true ']'
+ exec
STEP 5: COMMIT xxxxx
--> 2aec838cf4c
Successfully tagged xxxxx
2aec838cf4c3c9045134a104da350bbfeb2933527e93785b36b088c5bd894c69

```

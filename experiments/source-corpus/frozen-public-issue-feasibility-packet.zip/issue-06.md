# Expected Behavior

Only new or changed TaskRuns/PipelineRuns should produce CloudEvents.

Restarting `tekton-events-controller`, or the periodic 10h informer resync of unchanged terminal runs, should not re-deliver CloudEvents for runs that were already terminal before the controller started. At most, a small number of duplicates around the restart boundary would be acceptable.

The current docs say: "In case of controller restart, the cache is reset and a small number of duplicate events may be sent." (`docs/events.md`)

# Actual Behavior

On every restart/upgrade of `tekton-events-controller`, every terminal TaskRun and PipelineRun in the cluster is re-emitted to the configured sink. It is not a "small number"; it is 100% of the stored run history.

Observed on 2026-10-19 during an OpenShift Pipelines 1.23.2 -> 1.24.1 upgrade (new controller commit `8f9940e28516ce6c1788536272e81a087e97107e`):

- 410 CloudEvents sent in 4.3 seconds (13:17:47.442 - 13:17:51.755 UTC)
- 307 TaskRun events: 281 `taskrun.successful`, 26 `taskrun.failed`
- 103 PipelineRun events: 76 `pipelinerun.successful`, 27 `pipelinerun.failed`
- The emitted set was exactly all existing terminal runs: 103/103 PipelineRuns and 307/307 TaskRuns
- The oldest re-emitted object was created 2026-10-01 08:10 UTC (18 days old)

The same behavior was observed earlier on OpenShift Pipelines 1.23.2 (controller commit `92b039daa3abaeeff290111734cd9d91d30b7232`): the 10h informer resync re-sent 365 / 403 / 103 events at 2026-10-15 01:52 / 11:52 / 21:52 UTC, including runs created 2026-10-01..2026-10-14.

Example log line (names and sink redacted):

```text
2026-10-19T13:17:47.442Z ... reason: 'CloudEventSent' Sent dev.tekton.event.taskrun.successful.v1
```

# Steps to Reproduce the Problem

1. Configure a CloudEvents sink in `config-events` (`TektonConfig.spec.pipeline.options.configMaps.config-events.data.sink`).
2. Create several TaskRuns/PipelineRuns and let them reach a terminal state.
3. Restart the events controller:
   - OpenShift Pipelines: `kubectl -n openshift-pipelines rollout restart deploy/tekton-events-controller`
   - upstream: `kubectl -n tekton-pipelines rollout restart deploy/tekton-events-controller`
   - or upgrade OpenShift Pipelines / Tekton Pipelines so the pod is replaced.
4. Observe that every existing terminal TaskRun/PipelineRun is re-emitted to the sink immediately after startup.
5. Optional: leave the controller running and observe the 10h informer resync re-emit the subset whose in-memory cache entries were evicted.

# Additional Info

- Kubernetes version: v1.33.13 (OpenShift Container Platform 4.20.39)
- Tekton Pipeline version:
  - `8f9940e28516ce6c1788536272e81a087e97107e` (release-v1.15.x, shipped in OpenShift Pipelines 1.24.1)
  - `92b039daa3abaeeff290111734cd9d91d30b7232` (v1.12.x, shipped in OpenShift Pipelines 1.23.2)
- Sink: custom HTTPS endpoint configured via `config-events` (URL redacted)

Why this happens (from the current code):

- `pkg/reconciler/notifications/{taskrun,pipelinerun}/controller.go` registers `controller.HandleAll(impl.Enqueue)`, so the initial informer list and every 10h resync enqueue every TaskRun/PipelineRun.
- `pkg/reconciler/events/cache/cacheclient.go` configures an in-memory BigCache:

  ```go
  Shards:             16
  LifeWindow:         2 * time.Hour
  CleanWindow:        0
  MaxEntrySize:       64
  HardMaxCacheSize:   4096
  ```

- On startup the cache is empty, so `EmitCloudEvents` treats every terminal run as new and sends it.
- On a 10h resync, entries evicted since the previous resync are treated as new and re-sent. `LifeWindow` is shorter than the resync interval, and eviction is lazy (one oldest entry per new key insertion, per shard).

The code comment in `pkg/reconciler/events/cache/cache.go` says:

> "Once an event type is recorded here it is never re-sent for the same object, regardless of condition changes."

That is not true across restarts/evictions.

Suggested directions:

- Persist the last-sent condition snapshot per object (annotation/status/dedicated store) instead of relying only on an in-memory cache.
- On the initial list, skip objects that were already terminal before the controller started (e.g., using `completionTime` plus a persisted watermark), while still emitting events for runs that completed while the controller was down.
- For Update/resync events, compare against the persisted last-sent condition/resourceVersion and skip unchanged terminal runs.
- If the current behavior is intended, update `docs/events.md` and TEP-0137 to say that **all** terminal runs may be re-emitted after a restart, and make consumer idempotency an explicit requirement.

Workaround for consumers:

- Ignore events whose `data.<kind>.status.completionTime` is older than a threshold, and dedupe by `subject + type + completionTime`.
- Do not dedupe by the CloudEvent `id`; a new UUID is generated on every re-send.
- Prune old TaskRuns/PipelineRuns (`TektonConfig.spec.pruner`) to reduce the replay set.

Related:

- TEP-0137: https://github.com/tektoncd/community/blob/main/teps/0137-cloudevents-controller.md
- `docs/events.md`: https://github.com/tektoncd/pipeline/blob/main/docs/events.md
- #3617 (uniqueness not guaranteed): https://github.com/tektoncd/pipeline/issues/3617
- #5160 / #5313 (cache race): https://github.com/tektoncd/pipeline/issues/5160, https://github.com/tektoncd/pipeline/pull/5313
- TEP-0137 implementation: #9674, #9677, #6914, #9774

I searched for an existing issue for this exact behavior but could not find one; please close as duplicate if it is already tracked.

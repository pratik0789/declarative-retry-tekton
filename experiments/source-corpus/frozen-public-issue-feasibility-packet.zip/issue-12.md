/kind bug

# Expected Behavior

When a `ResolutionRequest` is labeled `resolution.tekton.dev/type: http`, only the HTTP resolver should reconcile it. Other resolvers (hub, git, bundle, cluster) should never process it.

On resolver pod restart or leader election, each resolver should only re-enqueue ResolutionRequests matching its own label selector.

# Actual Behavior

On leader election (triggered by pod startup, restart, or failover), `LeaderAwareFuncs.PromoteFunc` lists **all** ResolutionRequests using `labels.Everything()` and enqueues every one into **every** resolver's workqueue -- regardless of the `resolution.tekton.dev/type` label.

Since the reconciler's `Reconcile` method has no label guard, each resolver blindly calls `Validate()` and `Resolve()` on every dequeued request. When the incorrect resolver processes a ResolutionRequest it fails the RR with an error like `failed to validate params: missing required hub resolver params: name, version`, `missing required cluster resolver params: name, namespace`, `parameter \"bundle\" required`, or , `missing required git resolver params: pathInRepo`

This marks the ResolutionRequest's condition as `False` (permanent failure). When the correct HTTP resolver later picks up the same request via its properly-filtered informer path, it sees `IsDone() == true` and skips it, preventing the correct resolver from reconciling and fixing the RR's state.

The result is non-deterministic: depending on workqueue timing, some or all ResolutionRequests may be killed by the wrong resolver on any pod restart.

## Root Cause

`pkg/resolution/resolver/framework/controller.go` lines 158-174:

```go
func LeaderAwareFuncs(lister rrlister.ResolutionRequestLister) reconciler.LeaderAwareFuncs {
	return reconciler.LeaderAwareFuncs{
		PromoteFunc: func(bkt reconciler.Bucket, enq func(reconciler.Bucket, types.NamespacedName)) error {
			all, err := lister.List(labels.Everything())  // <-- BUG: no label filtering
			// ...
			for _, elt := range all {
				enq(bkt, types.NamespacedName{
					Namespace: elt.GetNamespace(),
					Name:      elt.GetName(),
				})
			}
			return nil
		},
	}
}
```

There is a TODO comment at line 154-157 acknowledging this:

```go
// TODO(sbwsg): I don't really understand the LeaderAwareness types beyond the
// fact that the controller crashes if they're missing. It looks
// like this is bucketing based on labels. Should we use the filter
// selector from above in the call to lister.List here?
```

The `remoteresolution` framework at `pkg/remoteresolution/resolver/framework/controller.go` line 58 reuses this same function, so all five built-in resolvers (git, hub, bundle, cluster, http) are affected.

The `FilteringResourceEventHandler` (registered in the same controller.go) correctly filters informer Add/Update events by label, but `PromoteFunc` bypasses this entirely.

# Steps to Reproduce the Problem

1. Clean slate:
```bash
kubectl delete resolutionrequests.resolution.tekton.dev --all
kubectl delete pipelineruns.tekton.dev --all
```

2. Stop all resolvers so ResolutionRequests accumulate unprocessed:
```bash
kubectl scale -n tekton-pipelines-resolvers deployment/tekton-pipelines-remote-resolvers --replicas=0
kubectl rollout status -n tekton-pipelines-resolvers deployment/tekton-pipelines-remote-resolvers
```

3. Create PipelineRuns that use the HTTP resolver:
```bash
for i in $(seq 1 500); do
  kubectl create -f examples/v1/pipelineruns/beta/http-resolver.yaml
done
```

4. Wait for the pipeline controller to create ResolutionRequests:
```bash
sleep 5
kubectl get resolutionrequests -o custom-columns=NAME:.metadata.name,TYPE:.metadata.labels.resolution\.tekton\.dev/type,STATUS:.status.conditions[0].status
```

5. Start the resolver -- `PromoteFunc` will enqueue all RRs into all resolver workqueues:
```bash
kubectl scale -n tekton-pipelines-resolvers deployment/tekton-pipelines-remote-resolvers --replicas=1
kubectl rollout status -n tekton-pipelines-resolvers deployment/tekton-pipelines-remote-resolvers
```

6. After ~10 seconds, check the results:
```bash
kubectl get resolutionrequests -o custom-columns=NAME:.metadata.name,TYPE:.metadata.labels.resolution\.tekton\.dev/type,STATUS:.status.conditions[0].status,MSG:.status.conditions[0].message
kubectl logs -n tekton-pipelines-resolvers deployment/tekton-pipelines-remote-resolvers --all-pods controller --max-log-requests=10 | grep -i 'Reconcile error' | cut -d ' ' -f 2- | jq .error
```

Some or all HTTP-labeled ResolutionRequests will show `STATUS=False` with message `"missing required hub resolver params: name, version"`, or similar messages from other resolvers

## Suggested Fix

Pass the resolver's label selector into `LeaderAwareFuncs` and use it for filtered listing:

```go
func LeaderAwareFuncs(lister rrlister.ResolutionRequestLister, selector map[string]string) reconciler.LeaderAwareFuncs {
	return reconciler.LeaderAwareFuncs{
		PromoteFunc: func(bkt reconciler.Bucket, enq func(reconciler.Bucket, types.NamespacedName)) error {
			all, err := lister.List(labels.SelectorFromSet(selector))
			...
```

# Additional Info

- Tekton Pipeline version: built from main at `e22b4b098`

- The bug has existed since `LeaderAwareFuncs` was introduced -- the TODO comment indicates it was a known concern from the beginning.
- All five built-in resolvers (git, hub, bundle, cluster, http) are affected.
- The bug is a race condition: it manifests non-deterministically depending on which resolver dequeues the request first. It is most reliably triggered by restarting the resolver deployment while ResolutionRequests are pending.

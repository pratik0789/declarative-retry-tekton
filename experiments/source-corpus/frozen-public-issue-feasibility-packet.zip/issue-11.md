# Expected Behavior

A clean, human-readable message without formatting artifacts, e.g.:

```
[User error] Optional workspace not supported by task
```

or, if keeping the cause detail:

```
[User error] Optional workspace not supported by task: <root cause message>
```

(But no %!w(...).)

# Actual Behavior

When a Pipeline fails due to an optional workspace mismatch, the user-facing error string sometimes contains a %!w(...) fragment, e.g.:

```yaml
status:
  completionTime: 2025-09-02T04:01:02Z
  conditions:
    - lastTransitionTime: 2025-09-02T04:01:02Z
      message: "[User error] Optional workspace not supported by task:
        %!w(*errors.UserError=&{[User error]  0xc00105c6b0})"
      reason: RequiredWorkspaceMarkedOptional
      status: "False"
      type: Succeeded
```

Note the %!w(*errors.UserError=...) suffix — a Go formatting artifact that leaks type names and pointers.

```
{"level":"info","ts":"2025-09-02T04:01:02.196Z","logger":"tekton-pipelines-controller.event-broadcaster","caller":"record/event.go:377","msg":"Event(v1.ObjectReference{Kind:\"PipelineRun\", Namespace:\"yzc-dev\", Name:\"helm-deploy-from-git-repo-qxnhl\", UID:\"865df62e-36bc-4168-8154-b8e5d278b8b6\", APIVersion:\"tekton.dev/v1\", ResourceVersion:\"29003316\", FieldPath:\"\"}): type: 'Warning' reason: 'Failed' [User error] Optional workspace not supported by task: %!w(*errors.UserError=&{[User error]  0xc00105c6b0})","commit":"347c03238a2694e37a9e2808820c712dd7e281e5","knative.dev/pod":"tekton-pipelines-controller-fc5976f94-mwdwn"}
```

# Steps to Reproduce the Problem

1. Create a Task with required workspace
2. Create a PipelineRun using Task, and do not mount that workspace

# Additional Info

- Kubernetes version:

  **Output of `kubectl version`:**

```
Client Version: v1.31.6-1
Kustomize Version: v5.4.2
Server Version: v1.31.6-1
```

- Tekton Pipeline version:

  **Output of `tkn version` or `kubectl get pods -n tekton-pipelines -l app=tekton-pipelines-controller -o=jsonpath='{.items[0].metadata.labels.version}'`**

```
v1.0.0
```


<!-- Any other additional information -->

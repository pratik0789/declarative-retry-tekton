# Expected Behavior
When a TaskRun's pod is evicted due to node resource pressure (exit code 137) and the controller successfully creates a replacement pod that eventually succeeds, the parent PipelineRun should reflect the TaskRun's final successful status.

# Actual Behavior
We observed unusual behavior with a TaskRun and PipelineRun. The TaskRun entered an Unknown state with reason "ExceededNodeResources" and message "TaskRun Pod exceeded available resources", where it remained stuck for approximately 5 minutes waiting for cluster resources.
The TaskRun then transitioned to Pending state with "PodReadyToStartContainers: False". Just one second later, the init container failed with exit code 137 and message "init container failed, 'prepare' exited with code 137: ContainerStatusUnknown".
This init container failure caused the PipelineRun to be marked as Failed with status "Tasks Completed: 4 (Failed: 1, Cancelled 0), Skipped: 14". All controllers (results, chains, kubearchive) started reconciling this failure.
However, the weird thing is that immediately after this, the TaskRun retried or something happened, and it went back to Unknown state with
"ExceededNodeResources" again. The TaskRun then entered Running state and eventually succeeded with "All Steps have completed executing".
The issue is that the PipelineRun remains in Failed state even though the TaskRun eventually succeeded.

# Additional Info
Observed Timeline
TaskRun controller logs:
```
  10:01:07  TaskRun → Unknown/ExceededNodeResources
            "TaskRun Pod exceeded available resources"

  10:01:18  TaskRun → Unknown/Pending
            "pod status \"PodReadyToStartContainers\":\"False\"; message: \"\""

  10:01:19  TaskRun → False/Failed
            "init container failed, \"prepare\" exited with code 137: ContainerStatusUnknown"

  10:01:20  TaskRun → Unknown/ExceededNodeResources   ← TaskRun retriggers with new pod
            "TaskRun Pod exceeded available resources"

  10:01:25  TaskRun → Unknown/Pending
            "Pending"

  10:01:33  TaskRun → Unknown/Pending
            "pod status \"Ready\":\"False\"; message: \"containers with unready status: [step-use-trusted-artifact step-build step-push
  step-sbom-syft-generate step-prepare-sboms step-upload-sbom]\""

  10:05:30  TaskRun → True/Succeeded
            "All Steps have completed executing"

```
  PipelineRun controller logs:
  ```
10:01:19  PipelineRun status → Running
            "Tasks Completed: 3 (Failed: 0, Cancelled 0), Incomplete: 15, Skipped: 0"

  10:01:20  PipelineRun status → Failed   ← reacted to the transient TaskRun failure
            "Tasks Completed: 4 (Failed: 1, Cancelled 0), Skipped: 14"

  10:01:20  Event Warning: 'Failed' Tasks Completed: 4 (Failed: 1, Cancelled 0), Skipped: 14
```

Full TaskRun reconciliation logs:
  ```
2026-01-16T10:01:07.436Z  Successfully reconciled taskrun swift-operator-1931c00b959f32d146472770cefe485f-build-container/openstack-tenant with
  status: &apis.Condition{Type:"Succeeded", Status:"Unknown", Reason:"ExceededNodeResources", Message:"TaskRun Pod exceeded available resources"}
  2026-01-16T10:01:18.683Z  Successfully reconciled taskrun ... Reason:"Pending", Message:"Pending"
  2026-01-16T10:01:18.743Z  Successfully reconciled taskrun ... Reason:"Pending", Message:"pod status \"PodReadyToStartContainers\":\"False\";
  message: \"\""
  2026-01-16T10:01:18.800Z  Successfully reconciled taskrun ... Reason:"Pending", Message:"pod status \"PodReadyToStartContainers\":\"False\";
  message: \"\""
  2026-01-16T10:01:18.812Z  Successfully reconciled taskrun ... Reason:"Pending", Message:"pod status \"PodReadyToStartContainers\":\"False\";
  message: \"\""
  2026-01-16T10:01:18.824Z  Successfully reconciled taskrun ... Reason:"Pending", Message:"pod status \"PodReadyToStartContainers\":\"False\";
  message: \"\""
  2026-01-16T10:01:18.918Z  Successfully reconciled taskrun ... Reason:"Pending", Message:"pod status \"PodReadyToStartContainers\":\"False\";
  message: \"\""
  2026-01-16T10:01:19.925Z  Successfully reconciled taskrun ... Status:"False", Reason:"Failed", Message:"init container failed, \"prepare\" exited
  with code 137: ContainerStatusUnknown"
  2026-01-16T10:01:20.576Z  taskrun openstack-tenant/swift-operator-1931c00b959f32d146472770cefe485f-build-container is still running
  2026-01-16T10:01:20.667Z  Successfully reconciled taskrun ... Status:"Unknown", Reason:"ExceededNodeResources", Message:"TaskRun Pod exceeded
  available resources"
  2026-01-16T10:01:25.367Z  Successfully reconciled taskrun ... Reason:"Pending", Message:"Pending"
  2026-01-16T10:01:25.513Z  Successfully reconciled taskrun ... Reason:"Pending", Message:"pod status \"PodReadyToStartContainers\":\"False\";
  message: \"\""
  2026-01-16T10:01:32.557Z  Successfully reconciled taskrun ... Reason:"Pending", Message:"pod status \"Initialized\":\"False\"; message:
  \"containers with incomplete status: [place-scripts]\""
  2026-01-16T10:01:33.475Z  Successfully reconciled taskrun ... Reason:"Pending", Message:"pod status \"Ready\":\"False\"; message: \"containers
  with unready status: [step-use-trusted-artifact step-build step-push step-sbom-syft-generate step-prepare-sboms step-upload-sbom]\""
  2026-01-16T10:05:30.985Z  Successfully reconciled taskrun ... Status:"True", Reason:"Succeeded", Message:"All Steps have completed executing"
```

PipelineRun controller logs:
  ```
2026-01-16T10:01:19.018Z  PipelineRun swift-operator-openstack-18-0-on-pull-request-nvvsc status is being set to &{Succeeded Unknown {2026-01-16
  09:55:34 +0000 UTC} Running Tasks Completed: 3 (Failed: 0, Cancelled 0), Incomplete: 15, Skipped: 0}
  2026-01-16T10:01:19.578Z  PipelineRun swift-operator-openstack-18-0-on-pull-request-nvvsc status is being set to &{Succeeded Unknown {2026-01-16
  09:55:34 +0000 UTC} Running Tasks Completed: 3 (Failed: 0, Cancelled 0), Incomplete: 15, Skipped: 0}
  2026-01-16T10:01:20.620Z  Event(PipelineRun "swift-operator-openstack-18-0-on-pull-request-nvvsc"): type: 'Warning' reason: 'Failed' Tasks
  Completed: 4 (Failed: 1, Cancelled 0), Skipped: 14
  2026-01-16T10:01:20.620Z  PipelineRun swift-operator-openstack-18-0-on-pull-request-nvvsc status is being set to &{Succeeded False {2026-01-16
  10:01:20.619475111 +0000 UTC} Failed Tasks Completed: 4 (Failed: 1, Cancelled 0), Skipped: 14}
```

  Impact

  - PipelineRun remains permanently Failed even though the TaskRun succeeded
  - 14 dependent tasks were skipped unnecessarily
  - Controllers (results, chains, kubearchive) started reconciling the false failure


<!-- Any other additional information -->

# Description
I have a pipeline that uses the git-clone task to clone a repository to a workspace. I do this for two different workspaces. Next, I attempt to pass both workspaces into a task. When running this pipeline, I see that it gets stuck on the task that I pass both workspaces into. (This task works fine when only one of the two workspaces is passed in).

# Expected Behavior
Task finishes successfully.
# Actual Behavior
Task is stuck in "PENDING".

When looking in the pod, I see this.
```
message: containers with incomplete status: [place-tools]
reason: ContainersNotInitialized
status: "False"
type: Initialized
```

# Steps to Reproduce the Problem

1. Create a pipeline 1. git-clone into a workspace, 2. git-clone into another workspace, 3. pass both workspaces into a task.
2. Run the pipeline.
3. Look at the pipelinerun and the taskruns resulting from the run. (Stuck in "PENDING")


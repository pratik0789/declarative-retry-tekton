# Expected Behavior

`git-clone` task succeeds

# Actual Behavior

`git-clone` task fails

# Steps to Reproduce the Problem

1. `kubectl apply -f pipeline.yaml` from the attached [repro.zip](https://github.com/tektoncd/catalog/files/9305481/repro.zip)
2. `kubectl create -f pipelinerun.yaml` from [repro.zip](https://github.com/tektoncd/catalog/files/9305481/repro.zip)
3. With `git-clone` version `0.7` it succeeds
4. With `git-clone` version `0.8` it fails

# Additional Info

The failure occurs after this log line:
`[fetch-source : clone] + rm -rf /workspace/output//lost+found`
which I assume is because https://github.com/tektoncd/catalog/pull/1034 has `git-clone` executing as a non-root user.

Here is the [code being executed at that time](https://github.com/tektoncd/catalog/blob/main/task/git-clone/0.8/git-clone.yaml#L199-L216).

I tried working around this issue by tweaking the params in my `pipeline.yaml`:
```
    params:
    - name: deleteExisting
      value: "false"
```

But that just moves the error over to `git-init`:

```
[clone] + /ko-app/git-init '-url=https://github.com/bendory/mini-true.git' '-revision=' '-refspec=' '-path=/workspace/output/' '-sslVerify=true' '-submodules=true' '-depth=1' '-sparseCheckoutDirectories='
[clone] {"level":"error","ts":1660183685.4823325,"caller":"git/git.go:55","msg":"Error running git [init /workspace/output/]: exit status 1\n/workspace/output/.git: Permission denied\n","stacktrace":"github.com/tektoncd/pipeline/pkg/git.run\n\tgithub.com/tektoncd/pipeline/pkg/git/git.go:55\ngithub.com/tektoncd/pipeline/pkg/git.Fetch\n\tgithub.com/tektoncd/pipeline/pkg/git/git.go:84\nmain.main\n\tgithub.com/tektoncd/pipeline/cmd/git-init/main.go:53\nruntime.main\n\truntime/proc.go:225"}
[clone] {"level":"fatal","ts":1660183685.4831095,"caller":"git-init/main.go:54","msg":"Error fetching git repository: exit status 1","stacktrace":"main.main\n\tgithub.com/tektoncd/pipeline/cmd/git-init/main.go:54\nruntime.main\n\truntime/proc.go:225"}
```
### Feature request

When a PipelineRun references a Pipeline using a resolver, and the Pipeline references Tasks using resolvers, the PipelineRun starts once the ResolutionRequests for the Pipeline and each Task are completed. 

At this point, the ResolutionRequests are complete and serve no purpose (as far as I can tell). They can be deleted while their parent PipelineRun executes without side effects.  Especially since all of a PipelineRun's Task's ResolutionRequests have their PipelineRun as their owner; if a pipelineRun references a large but quick task and afterwards runs a small but long taskrun, the large task's resolutionrequests remains in etcd long after the relevant TaskRun has completed. 

### Use case

This would reduce the etcd storage footprint of pipelineruns significantly, particularly for environments which heavily use remote resolution, large pipeline and task definitions, and and long-running Tasks and Pipelines. 


#### Example
For example, [this pipelineRun](https://github.com/aThorp96/tekton-pipeline/blob/test-resolutionrequest-size/git-resolver-pipelinerun.yaml) references [this Pipeline](https://github.com/aThorp96/tekton-pipeline/blob/test-resolutionrequest-size/git-resolver-pipeline.yaml) using the git resolver, and that Pipeline in turn references [this Task](https://github.com/tektoncd/catalog/tree/55dd80ef1b83861613dce9080dfdf6656f1aecd4/task/git-clone/0.10/git-clone.yaml) using the git resolver. 

After creating this pipelineRun and waiting for it to complete, we can get the pipelinerun and child objects' yaml to estimate its etcd footprint in bytes:
```
 $ kubectl get $(
                                                            kubectl get taskruns,pods,resolutionrequests,customruns,pipelineruns,statefulsets,pvc -n default -o json | jq -r '.items[] | select(.metadata.name == "git-resolver-kc99w" or ([.metadata.ownerReferences[]? | .name] | any(. | startswith("git-resolver-kc99w")))) | "\(.kind)/\(.metadata.name)"' \
                                                        )
NAME                                          SUCCEEDED   REASON      STARTTIME   COMPLETIONTIME
taskrun.tekton.dev/git-resolver-kc99w-task1   True        Succeeded   2m53s       2m45s

NAME                               READY   STATUS      RESTARTS   AGE
pod/git-resolver-kc99w-task1-pod   0/1     Completed   0          2m53s

NAME                                                                           OWNERKIND     OWNER                SUCCEEDED   REASON   STARTTIME              ENDTIME
resolutionrequest.resolution.tekton.dev/git-24f136bea5d40ab083b1c0785fca63d1   PipelineRun   git-resolver-kc99w   True                 2026-09-03T17:36:07Z   2026-09-03T17:36:09Z
resolutionrequest.resolution.tekton.dev/git-2f4462c67e827a56cae2c16dcb5c7417   PipelineRun   git-resolver-kc99w   True                 2026-09-03T17:36:01Z   2026-09-03T17:36:07Z

NAME                                        SUCCEEDED   REASON      STARTTIME   COMPLETIONTIME
pipelinerun.tekton.dev/git-resolver-kc99w   True        Succeeded   3m1s        2m45s

NAME                                   STATUS   VOLUME                                     CAPACITY   ACCESS MODES   STORAGECLASS   VOLUMEATTRIBUTESCLASS   AGE
persistentvolumeclaim/pvc-08db9dc5fb   Bound    pvc-e722436d-0399-48fd-ad27-149a1d46c2cd   1Gi        RWO            standard       <unset>                 2m53s


 $ kubectl get -oyaml $(
                                                            kubectl get taskruns,pods,resolutionrequests,customruns,pipelineruns,statefulsets,pvc -n default -o json | jq -r '.items[] | select(.metadata.name == "git-resolver-kc99w" or ([.metadata.ownerReferences[]? | .name] | any(. | startswith("git-resolver-kc99w")))) | "\(.kind)/\(.metadata.name)"' \
                                                        ) | wc -c
51390
```

After deleting the resolutionrequests and rerunning the above command we can see proportionally how much disk was used for the ResolutionRequests:
```
$ kubectl get resolutionrequests.resolution.tekton.dev -n default -o json | \
                                                              jq -r '.items[] | select(
                                                            [.metadata.ownerReferences[]? | .name] | index("git-resolver-kc99w")
                                                          ) | .metadata.name' | \
                                                              xargs kubectl delete resolutionrequests.resolution.tekton.dev
resolutionrequest.resolution.tekton.dev "git-24f136bea5d40ab083b1c0785fca63d1" deleted
resolutionrequest.resolution.tekton.dev "git-2f4462c67e827a56cae2c16dcb5c7417" deleted

 $ kubectl get -oyaml $(
                                                            kubectl get taskruns,pods,resolutionrequests,customruns,pipelineruns,statefulsets,pvc -n default -o json | jq -r '.items[] | select(.metadata.name == "git-resolver-kc99w" or ([.metadata.ownerReferences[]? | .name] | any(. | startswith("git-resolver-kc99w")))) | "\(.kind)/\(.metadata.name)"' \
                                                        ) | wc -c
33874
```

*A roughly 35% reduction in yaml object size.* 


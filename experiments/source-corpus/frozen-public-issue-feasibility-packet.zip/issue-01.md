Title: PipelineRun enum subset validation skips later parameters when an earlier Task param has no enum

# Expected Behavior

With `enable-param-enum: "true"`, every direct Pipeline param reference passed to a Task param with an enum should be checked. A Pipeline param enum of `[v1, v2]` must fail validation when the corresponding Task param enum is `[v1]`, regardless of the order of the Task's params. This follows the documented subset rule.

# Actual Behavior

`ValidateParamEnumSubset` returns `nil` as soon as it sees a referenced Pipeline param that is not string typed **or** a Task param without an enum. This exits the loop before checking later params. Thus, placing an unrelated Task param without an enum before the restricted param suppresses the subset error. Reversing only the param order produces the expected error.

Confirmed on a cluster running Tekton Pipelines v1.13.1 with `enable-param-enum: "true"` during the test:

```text
enum-free-first: status=Unknown reason=Running
TaskRun enum-free-first-consumer was created.

enum-restricted-first: status=False reason=PipelineValidationFailed
message=[User error] Validation failed for pipelinerun with error pipeline param "restricted" enum: [v1 v2] is not a subset of the referenced in "" task param enum: [v1]
```

The first run was still `Running` when its status was collected; the observed bug is that its invalid enum subset passed validation and created a TaskRun.

The early return is at `pkg/reconciler/pipelinerun/resources/pipelinerunresolution.go:1131-1133`; the controller calls this validation when `enable-param-enum` is enabled. A `continue` for the current param appears to be intended.

# Steps to Reproduce the Problem

1. Set `enable-param-enum: "true"` in the Tekton `feature-flags` ConfigMap.
2. Apply the following PipelineRun:

```yaml
apiVersion: tekton.dev/v1
kind: PipelineRun
metadata:
  name: enum-free-first
spec:
  params:
    - {name: free, value: hello}
    - {name: restricted, value: v1}
  pipelineSpec:
    params:
      - {name: free, type: string}
      - {name: restricted, type: string, enum: [v1, v2]}
    tasks:
      - name: consumer
        params:
          - {name: free, value: $(params.free)}
          - {name: restricted, value: $(params.restricted)}
        taskSpec:
          params:
            - {name: free, type: string}
            - {name: restricted, type: string, enum: [v1]}
          steps:
            - {name: run, image: busybox:1.36, script: "echo ok"}
```

3. Create a second PipelineRun under a different name, swapping only the two `spec.pipelineSpec.tasks[0].params` entries so `restricted` comes first. Compare both PipelineRun conditions and child TaskRuns. The selected runtime value `v1` is individually valid, but `[v1, v2]` is not a subset of `[v1]`; both runs should fail the subset check.

The following small Go reproduction also exercises the controller's validator directly:

```go
params := []v1.Param{
    {Name: "free", Value: *v1.NewStructuredValues("$(params.free)")},
    {Name: "restricted", Value: *v1.NewStructuredValues("$(params.restricted)")},
}
pipelineParams := []v1.ParamSpec{
    {Name: "free", Type: v1.ParamTypeString},
    {Name: "restricted", Type: v1.ParamTypeString, Enum: []string{"v1", "v2"}},
}
task := &taskresources.ResolvedTask{
    TaskName: "consumer",
    TaskSpec: &v1.TaskSpec{Params: v1.ParamSpecs{
        {Name: "free", Type: v1.ParamTypeString},
        {Name: "restricted", Type: v1.ParamTypeString, Enum: []string{"v1"}},
    }},
}
fmt.Println(pipelinerunresources.ValidateParamEnumSubset(params, pipelineParams, task))
fmt.Println(pipelinerunresources.ValidateParamEnumSubset([]v1.Param{params[1], params[0]}, pipelineParams, task))
```

Output:

```text
<nil>
pipeline param "restricted" enum: [v1 v2] is not a subset of the referenced in "consumer" task param enum: [v1]
```

# Additional Info

- Kubernetes version:

  **Output of `kubectl version`:**

  ```text
  Client Version: v1.33.3
  Kustomize Version: v5.6.0
  Server Version: v1.34.3
  ```

- Tekton Pipeline version:

  **Output of `kubectl get pods -n tekton-pipelines -l app=tekton-pipelines-controller -o=jsonpath='{.items[0].metadata.labels.version}'`:**

  ```text
  v1.13.1
  ```
- Also reproduced directly against `tektoncd/pipeline` source commit `d3ddd0fd9fbfe5d0a34ad51632f69e4e4a2c2da7` (2026-07-28).
- Relevant docs: https://github.com/tektoncd/pipeline/blob/main/docs/pipelines.md#param-enum
- Suggested regression test: Put a param without a Task enum before one with an invalid enum subset, then assert that `ValidateParamEnumSubset` still reports the latter.

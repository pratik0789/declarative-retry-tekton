# Expected Behavior

# Actual Behavior

when using, this template https://hub.tekton.dev/tekton/task/npm , cannot send **" run build "** as args to npm command  and the task is failed

this is the error : 

```
Usage: npm <command>

where <command> is one of:
    access, adduser, audit, bin, bugs, c, cache, ci, cit,
    clean-install, clean-install-test, completion, config,
    create, ddp, dedupe, deprecate, dist-tag, docs, doctor,
    edit, explore, get, help, help-search, hook, i, init,
    install, install-ci-test, install-test, it, link, list, ln,
    login, logout, ls, org, outdated, owner, pack, ping, prefix,
    profile, prune, publish, rb, rebuild, repo, restart, root,
    run, run-script, s, se, search, set, shrinkwrap, star,
    stars, start, stop, t, team, test, token, tst, un,
    uninstall, unpublish, unstar, up, update, v, version, view,
    whoami

npm <command> -h  quick help on <command>
npm -l            display full usage info
npm help <term>   search for help on <term>
npm help npm      involved overview

Specify configs in the ini-formatted file:
    /tekton/home/.npmrc
or on the command line via: npm <command> --key value
Config info can be viewed via: npm help config

npm@6.7.0 /usr/local/lib/node_modules/npm

Did you mean this?
    rebuild
Step failed
```

# Additional Info

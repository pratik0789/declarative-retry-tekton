# Expected Behavior

`finally` tasks are documented to be "guaranteed to be executed in order after the `Tasks` under `tasks` have completed regardless of success or error" ([docs/pipelines.md](https://github.com/tektoncd/pipeline/blob/main/docs/pipelines.md#guard-finally-task-execution-using-when-expressions)).

When the API server permanently refuses to create the child run of a `PipelineTask` - an admission policy denying it, for instance - that `PipelineTask` should count as failed, the DAG should converge, and the `finally` tasks should still run so that the notification or cleanup a pipeline relies on them for is not lost. The `PipelineRun` should still end up failed.

# Actual Behavior

The whole `PipelineRun` is failed on the spot with `CreateRunFailed`:

- no child `TaskRun` is created at all,
- `skippedTasks` is empty,
- the `finally` tasks are **never scheduled**.

The rejection is handled in `handleRunCreationError`, which marks the `PipelineRun` failed and returns a permanent error from inside the creation loop. The reconcile returns before `GetFinalTasks()` is ever reached, and the next reconcile short circuits because the `PipelineRun` is already done.

This looks like a gap rather than a deliberate design, for three reasons:

1. **The layer below does the opposite.** `handlePodCreationError` (`pkg/reconciler/taskrun/taskrun.go`) turns a Pod that admission refused - and even an unknown creation error - into a failed `TaskRun`. No branch of it fails the parent `PipelineRun`, precisely so that the parent can converge normally.
2. **The same layer already models this.** `ValidationFailedTask` (`pkg/reconciler/pipelinerun/resources/pipelinerunstate.go`) is described as "the tasks for which taskrun is not created as they never got added to the execution": such a task has no child run, yet it counts as done so the DAG converges and `finally` runs.
3. **The documented `finally` guarantee** quoted above.

# Steps to Reproduce the Problem

1. Install a policy that refuses the child `TaskRun` of one pipeline task. Any validating webhook does; with Kyverno:

```yaml
apiVersion: kyverno.io/v1
kind: ClusterPolicy
metadata:
  name: deny-gate-taskrun
spec:
  background: false
  rules:
    - name: deny-gate-taskrun
      match:
        any:
          - resources:
              kinds:
                - TaskRun
              selector:
                matchLabels:
                  tekton.dev/pipelineTask: gate
      validate:
        failureAction: Enforce
        message: gate params are not compliant with the release policy
        deny:
          conditions:
            any:
              - key: "true"
                operator: Equals
                value: "true"
```

2. Run a pipeline whose gated task is refused, with a `finally` task that notifies on failure:

```yaml
apiVersion: tekton.dev/v1
kind: PipelineRun
metadata:
  generateName: finally-starved-
spec:
  pipelineSpec:
    tasks:
      - name: gate
        taskSpec:
          steps:
            - name: gate
              image: busybox
              script: |
                echo "gate passed"
      - name: release
        runAfter:
          - gate
        taskSpec:
          steps:
            - name: release
              image: busybox
              script: |
                echo "released"
    finally:
      - name: notify
        when:
          - input: $(tasks.status)
            operator: in
            values:
              - Failed
        taskSpec:
          steps:
            - name: notify
              image: busybox
              script: |
                echo "notifying"
```

3. Observe the `PipelineRun`:

```
status:
  conditions:
    - reason: CreateRunFailed
      status: "False"
      type: Succeeded
```

No `TaskRun` exists, `skippedTasks` is empty, and `notify` never ran.

Two further details make the second one hard to work around even if `finally` did run: a task whose child run was rejected has no run to read an execution status from, so `$(tasks.<name>.status)` reports `None` and the aggregate `$(tasks.status)` still aggregates to `Completed`. A `finally` task guarded on a failure of the pipeline - the shape a notification usually has - would be skipped as well.

# Additional Info

- Kubernetes version: v1.34.5
- Tekton Pipeline version: v1.12.2

The behaviour was introduced in 937c8c02 ("Fail PipelineRun when it can't create Runs"), which changed a non-retryable creation failure from an endless retry into `MarkFailed` plus a permanent error. That intent is sound - the retry loop left the status out of sync with the cluster - but starving `finally` looks like an unintended consequence of it. The commit was first released in v0.50.0, so every release since is affected, up to and including v1.15.0 and `main`.

Related, but distinct: #8982 (finally cancelled when the tasks timeout is reached), #8110 (accessing `reason` from the execution status in `finally`), #6214 (surfacing failed task information to `finally`).

# Expected Behavior

A task should reference one of the defined workspaces.

# Actual Behavior

Undefined workspace referenced.

# Additional Info

One of the tasks- buildah, in this [dockerconfig.yaml](https://github.com/tektoncd/catalog/blob/main/task/buildah/0.5/samples/dockerconfig.yaml)  references a [workspace](https://github.com/tektoncd/catalog/blob/main/task/buildah/0.5/samples/dockerconfig.yaml#L52) which is not defined in the PipelineRun's [spec.pipelineSpec.workspaces](https://github.com/tektoncd/catalog/blob/main/task/buildah/0.5/samples/dockerconfig.yaml#L23).

# Fixes

The simple fix is to rename the workspace.
# Expected Behavior

When a PipelineRun contains multiple independent remote `taskRef` or `pipelineRef` entries, the PipelineRun controller should submit every reference that can be attempted during the current reconciliation.

TaskRun and child PipelineRun creation should remain blocked until all required references are resolved.

# Actual Behavior

`resolvePipelineState` returns as soon as one reference reports `ErrRequestInProgress`. References later in the Pipeline are not submitted until a later PipelineRun reconciliation.

The controller also returns after a pending reference in the ran/running task partition, before attempting the not-started partition.

This makes remote-reference submission latency grow with the number of distinct unresolved references and the delay between PipelineRun reconciliations. Large Pipelines can therefore spend significant time in `ResolvingTaskRef` before all ResolutionRequests have even been created.

There is no specific task-count limit where a Pipeline becomes invalid. A Pipeline with around 205 remote TaskRefs exposed the behavior, but `205` is not a threshold and observed startup time also depends on API throttling, resolver capacity, cache state, and controller queue latency.

Local `taskRef.name` lookups and inline `taskSpec` entries do not use this ResolutionRequest path.

# Steps to Reproduce the Problem

1. Create a Pipeline containing several independent tasks with remote resolver references and distinct parameters.
2. Create a PipelineRun for it.
3. Observe ResolutionRequest creation and PipelineRun reconciliation.

Before the fix, the first unresolved reference causes an immediate delayed requeue and later references are submitted on subsequent reconciliations.

# Additional Info

- Kubernetes version:

  This behavior is not Kubernetes-version specific.

  **Output of `kubectl version`:**

```
Not applicable.
```

- Tekton Pipeline version:

  Reproduced against current `main` behavior before #10643.

  **Output of `tkn version` or `kubectl get pods -n tekton-pipelines -l app=tekton-pipelines-controller -o=jsonpath='{.items[0].metadata.labels.version}'`:**

```
Current development version.
```

<!-- Any other additional information -->

## Acceptance criteria

- A pending remote reference does not prevent later independent references from being attempted in the same reconciliation.
- References in both the ran/running and not-started task partitions are attempted before one delayed requeue is returned.
- No TaskRuns or child PipelineRuns are created while required references remain unresolved.
- A permanent or transient error encountered after a pending reference is still returned with its existing semantics.
- After the references complete, reconciliation creates the expected child Runs without duplicate ResolutionRequests.
- Regression coverage exercises multiple independent references and both task partitions.

## Non-goals

- Changing the one-second fallback requeue tracked by #10630.
- Changing resolver cache behavior or ResolutionRequest storage pressure discussed in #10644.
- Defining a maximum supported number of PipelineTasks.
- Increasing resolver worker capacity.

## Related

- #10630
- #10414
- #7116
- Discussion #10644
- PR #8925

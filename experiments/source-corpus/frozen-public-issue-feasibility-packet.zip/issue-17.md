# Expected Behavior
work as sample
# Actual Behavior
I am trying to run sample from https://github.com/tektoncd/catalog/blob/main/pipeline/buildpacks/0.2/samples/cache-volume.yaml 

When I add a persistentVolumeClaim(same claim as source-ws) for cache workspace. 
It always stuck at 'pod status "Initialized":"False"; message: "containers with incomplete status: [prepare place-scripts]"' . When I leave cache-ws as emptyDir: {}. It works fine.

Beginning, It deploys three Pods, affinity-assistant-4dc6699468-0, affinity-assistant-a577dc71dd-0 and env-var-pipeliner1uns-fetch-from-git-pod. Then I got errors as below:

env-var-pipeliner1uns-fetch-from-git-pod.1725cd50beafb500
FailedAttachVolume
Multi-Attach error for volume "pvc-fb80016f-3f91-4592-938e-8fef951800d9" Volume is already used by pod(s) affinity-assistant-a577dc71dd-0

Unable to attach or mount volumes: unmounted volumes=[ws-bhn87], unattached volumes=[tekton-internal-home tekton-internal-workspace tekton-internal-bin kube-api-access-4rb6r tekton-internal-downward tekton-internal-steps tekton-internal-run-0 tekton-internal-scripts ws-bhn87 tekton-internal-results tekton-creds-init-home-0]: timed out waiting for the condition

Is this an expected Behaviour? 

Tekton version: 0.40.2
buildpacks Task version: 0.5 https://hub.tekton.dev/tekton/task/buildpacks
git clone version: 0.9 https://hub.tekton.dev/tekton/task/git-clone
Pipeline: https://hub.tekton.dev/tekton/pipeline/buildpacks

# Steps to Reproduce the Problem

1.
2.
3.

# Additional Info

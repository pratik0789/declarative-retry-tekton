
### Feature request

Surface actionable infrastructure failure reasons (from Pod Events) onto the
`TaskRun` status when a Pod is stuck starting and the Pod object itself carries
no useful information.

When a Pod fails to *start* (as opposed to a Step failing at runtime), there are
no container logs, because no container ever runs. In many of these cases the
Pod object contains enough for Tekton to explain the problem, and Tekton already
does a good job here in `pkg/pod/status.go` (`updateIncompleteTaskRunStatus`):

- Unschedulable due to insufficient resources → `ExceededNodeResources`
- Missing Secret/ConfigMap referenced via `envFrom` / `env.valueFrom`, or bad
  container config → `CreateContainerConfigError` (with a message)
- `ImagePullBackOff` / `ErrImagePull` / `InvalidImageName` / … → `PullImageFailed`
- Otherwise `getWaitingMessage()` falls back to the container waiting message,
  then to non-`True` Pod conditions, then to `pod.Status.Message`.

There is, however, a category of failures where **the actionable detail exists
only as a Kubernetes Event and is never written to any field of the Pod
object**. The canonical example is a Secret/ConfigMap that is missing but
mounted as a **volume** (rather than referenced via env). In that case:

- `pod.status.phase` stays `Pending`
- the container is stuck with `state.waiting.reason: ContainerCreating` and an
  **empty** message
- Pod conditions only say `containers with unready status: [step-x]`
- the real reason is emitted only as a `Warning` Event with reason `FailedMount`

As a result, `getWaitingMessage()` can only produce something like
`build step "step-x" is pending with reason "ContainerCreating"`, and the
TaskRun sits in that state until it times out with no indication of the cause.

The missing-Secret-volume case is the cleanest example, but the same problem
(detail lives only in an Event; Pod shows generic `Pending`/`ContainerCreating`)
applies to several other failure modes:

- **Volume mount/attach** (all volume types): `FailedMount` /
  `FailedAttachVolume` ("Volume is already exclusively attached to one node",
  mount timeouts).
- **PVC not bound / not provisioned**: `FailedScheduling` ("pod has unbound
  immediate PersistentVolumeClaims") or PVC `ProvisioningFailed`.
- **CNI / sandbox**: `FailedCreatePodSandBox` ("failed to set up sandbox
  container … network …") — no container status at all.
- **Scheduling detail**: `FailedScheduling` ("0/N nodes are available: … had
  untolerated taint / didn't match node affinity …"); only the terse
  `Unschedulable` condition is on the Pod (insufficient-resources is already
  handled by Tekton).

A related but distinct case is **admission/quota rejection at pod-creation time**
(`ExceededResourceQuota`, PodSecurity/LimitRange/webhook denials): here the Pod
may never be created, so there is no Pod UID to look up — the event has to be
read from the pod-create call / owning object. Worth handling as a separate
sub-problem.

#### Reproduction

A Pod that mounts a non-existent Secret as a volume:

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: missing-secret-volume
spec:
  containers:
  - name: step
    image: registry.k8s.io/pause:3.9
    volumeMounts:
    - name: vol
      mountPath: /etc/foo
  volumes:
  - name: vol
    secret:
      secretName: does-not-exist
```

The Pod status (trimmed) — note the empty waiting message and generic conditions:

```yaml
status:
  phase: Pending
  conditions:
  - type: Ready
    status: "False"
    reason: ContainersNotReady
    message: 'containers with unready status: [step]'
  - type: ContainersReady
    status: "False"
    reason: ContainersNotReady
    message: 'containers with unready status: [step]'
  - type: PodScheduled
    status: "True"
  containerStatuses:
  - name: step
    state:
      waiting:
        reason: ContainerCreating   # <- no message
```

The only place the cause appears:

```
$ kubectl get events --field-selector involvedObject.uid=<pod-uid>,type=Warning
Warning  FailedMount  MountVolume.SetUp failed for volume "vol" : secret "does-not-exist" not found
```

### Use case

A user submits a PipelineRun that references a Secret/ConfigMap as a workspace
or volume that doesn't exist (typo, not yet created, wrong namespace). The
TaskRun's Pod never starts. Today the TaskRun stays `Running`/`Pending` with a
message like `build step "step-x" is pending with reason "ContainerCreating"`
until it times out — with no logs and no reason. The user (or their support
team) has to reach for `kubectl describe pod` / `kubectl get events`, which:

- requires cluster access the user may not have (shared/multi-tenant clusters),
- requires Kubernetes expertise to interpret,
- is often impossible after the fact, because Events may be short-lived.

If Tekton copied the distilled reason onto the TaskRun status, the information
would be visible through the normal status the user already consumes, and — 
importantly — it would be **persisted** with the TaskRun (and anything that
archives TaskRuns, e.g. Results), so it survives long after the Event is gone.

### Proposed (low-cost) implementation

Only in the case where the Pod is `Pending`/`ContainerCreating` **and** the Pod
object yields no useful message, do a single, targeted Events **List** scoped to
that one Pod, and surface the most recent `Warning` event's reason + message
onto the TaskRun status condition.

Extend the `default` branch of `updateIncompleteTaskRunStatus` in
`pkg/pod/status.go`:

```go
default:
    msg := getWaitingMessage(pod)
    if isGenericPending(msg) { // e.g. reason "ContainerCreating" with no detail
        if evReason, evMsg := latestWarningEvent(ctx, kubeclient, pod); evMsg != "" {
            msg = fmt.Sprintf("%s: %s", evReason, evMsg)
        }
    }
    markStatusRunning(trs, ReasonPodPending, msg)
```

where the lookup is a field-selected List for the specific Pod (no informer, no
watch):

```go
events, _ := kube.CoreV1().Events(pod.Namespace).List(ctx, metav1.ListOptions{
    FieldSelector: fmt.Sprintf("involvedObject.uid=%s,type=Warning", pod.UID),
})
```

Why this is intentionally cheap:

- **Opt-in first.** Ship it behind a feature flag (e.g. `surface-pod-events`,
  disabled by default) so clusters can enable it deliberately, and we can
  validate behaviour/cost before considering it on-by-default.
- **No new watch/informer on Events.** The existing Pod informer already
  triggers a TaskRun reconcile when the Pod changes; we merely add a
  per-Pod List, and only when the Pod is stuck with no useful status. This
  avoids the well-known etcd pressure of watching Events cluster/namespace wide.
- **Nothing new is exposed to end users** beyond a single curated line placed on
  the TaskRun status. The controller decides what to copy, so it can be limited
  to `Warning` events / an allowlist of reasons if desired.
- **Persistence for free:** because it lands on `TaskRun.status`, the reason
  outlives the Event, whose retention is cluster-dependent and may be short.

Implementation notes / open questions:

- RBAC: the controller ClusterRole currently has only `create/update/patch` on
  `events`; this needs `get`/`list` added.
- Consider gating behind a feature flag (e.g. `surface-pod-events`) for a safe,
  opt-in rollout.
- Decide the selection policy when multiple Warning events exist (most recent,
  or a reason allowlist such as `FailedMount`, `FailedScheduling`,
  `FailedCreatePodSandBox`).
- Bound the message length written to status.

### Alternatives to consider

1. **Enrich only from the Pod object (no events at all).** Free and simplest,
   but as shown above it cannot cover the volume-mount case, because the detail
   is never written to the Pod — so this is insufficient on its own. Still worth
   doing for the cases where the Pod *does* carry a message.
2. **Watch/informer on Events.** More responsive and could reflect updates
   continuously, but introduces ongoing etcd load and complexity — the opposite
   of the goal.
3. **A dedicated `infra`/`events` sub-resource or field on TaskRun status**
   (structured list of relevant events) instead of folding into the condition
   message. Richer for UIs, but larger API surface and status size; could be a
   follow-up if the single-message approach proves too limited.
4. **Leave it to external tooling** (dashboards/log collectors) to correlate
   events. Doesn't solve the "no access / no persistence / needs k8s expertise"
   problems for the user looking at the TaskRun.

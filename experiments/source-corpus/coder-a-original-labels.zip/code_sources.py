import pathlib,json,yaml,re,hashlib,collections,datetime
P=pathlib.Path('/tmp/tekton-value-corpus-worker/frozen-source-packet');O=pathlib.Path('/tmp/tekton-static-coder-a');S=json.loads((P/'selected-compositions.json').read_text())
cache={}
def mapping(n):return {k.value:v for k,v in n.value}if isinstance(n,yaml.MappingNode)else{}
def nodes(n):
 yield n
 if isinstance(n,yaml.MappingNode):
  for k,v in n.value:yield from nodes(v)
 elif isinstance(n,yaml.SequenceNode):
  for v in n.value:yield from nodes(v)
def getfile(f):
 if f not in cache:
  raw=(P/f).read_text();cache[f]=(raw.splitlines(),list(yaml.compose_all(raw)))
 return cache[f]
def specnode(f,spec):
 lines,docs=getfile(f)
 for doc in docs:
  for n in nodes(doc):
   if isinstance(n,yaml.MappingNode)and ('steps'in mapping(n) or 'image'in mapping(n)):
    try:
     if yaml.SafeLoader('').construct_object(n,deep=True)==spec:return n
    except Exception:pass
 raise ValueError('No spec match '+f)
def cite(f,n):
 lines,_=getfile(f);a=n.start_mark.line+1;b=max(a,n.end_mark.line+(1 if n.end_mark.column else 0));return {'source_file':f,'source_lines':[a,b],'source_quote':'\n'.join(lines[a-1:b])}
def textcite(f,text):
 lines,_=getfile(f)
 for i,l in enumerate(lines):
  if text in l:return {'source_file':f,'source_lines':[i+1,i+1],'source_quote':l}
 return {'source_file':f,'source_lines':[1,len(lines)],'source_quote':'\n'.join(lines)}
def scripts(n):
 m=mapping(n);values=[]
 for key in ['script','command','args']:
  if key in m:values.append((key,m[key],yaml.SafeLoader('').construct_object(m[key],deep=True)))
 return values
patterns=[
 ('local-state removal',r'(^|[;&|\s])rm\s+(?:-[a-zA-Z]+\s+)*','Source-explicit'),
 ('local directory initialization',r'(^|[;&|\s])mkdir\s','Source-explicit'),
 ('local file copying/moving',r'(^|[;&|\s])(?:cp|mv)\s','Source-explicit'),
 ('local file availability guard',r'(?:\[\[?|test)\s+(?:!\s+)?-[fedr]\s','Source-explicit'),
 ('Kubernetes API read/availability check',r'(?:kubectl|oc)\s+(?:-n\s+[^ ]+\s+)?(?:get|wait|whoami)\b','Source-explicit'),
 ('Kubernetes API mutation request',r'(?:kubectl|oc)\s+(?:-n\s+[^ ]+\s+)?(?:apply|create|patch|replace|delete)\b','Source-explicit'),
 ('remote HTTP request',r'(^|[;&|\s])(?:curl|wget)\s','Source-explicit'),
 ('registry inspection request',r'\bskopeo\s+inspect\b','Source-explicit'),
 ('registry copy request',r'\bskopeo\s+copy\b','Source-explicit'),
 ('Git remote write request',r'\bgit\s+push\b','Source-explicit'),
 ('Git remote retrieval/rebase request',r'\bgit\s+(?:pull|fetch|clone)\b','Source-explicit'),
 ('local Git index/history mutation',r'\bgit\s+(?:reset|add|commit|config|rebase)\b','Source-explicit'),
 ('result file publication',r'(?:>|tee\s+)\s*["\']?\$\((?:results|step.results)\.[^\s)]+\.path\)','Source-explicit'),
 ('registry signature invocation',r'\b(?:cosign|run_cosign)\b[^\n]*\bsign\b','Interface-supported'),
]
effects=[];coverage=[];task_entries={}
def add(r,t,kind,c,confidence='Source-explicit',opaque='Runtime implementation, external service behavior and branch execution are not verified.',step=None):
 rec={'effect_id':'A-E'+str(len(effects)+1).zfill(5),'pipeline_id':r['pipeline_id'],'task_name':t['task_name'],'phase':t['phase'],'step_name':step,'effect_or_precondition':kind,'state_item':c['source_quote'],'confidence':confidence,'opaque_boundary':opaque,'warning_visibility_basis':'Within-Task source operation; no actual planner warning or cross-task dependency follows solely from this label.','backward_policy_expressibility_basis':'Whole-Task retry repeats the operation if this branch executes; cross-task policy membership is not established by this label.'};rec.update(c);effects.append(rec);return rec['effect_id']
for r in S:
 comp={'pipeline_id':r['pipeline_id'],'repo':r['repo'],'composition_file':r['composition_file'],'task_occurrences':[],'runtime_compatibility':'Unknown / not evaluated','relationship_completeness':'Unknown: source coding cannot discover opaque runtime effects.'}
 for t in r['resolved_tasks']:
  f=t.get('task_source_file')or r['composition_file'];n=specnode(f,t['task_spec']);steps=mapping(n).get('steps');ids=[];inspected={f};boundaries=[]
  for i,sn in enumerate(steps.value if steps else[]):
   st=t['task_spec']['steps'][i];name=st.get('name');sources=[(f,sn,st)]
   for h in t.get('referenced_stepactions',[]):
    if h['step_ordinal']==i:
     hf=h['source_file'];inspected.add(hf);sources.append((hf,specnode(hf,h['stepaction_spec']),h['stepaction_spec']))
   for sf,ss,body in sources:
    for key,vnode,v in scripts(ss):
     payload=v if isinstance(v,str)else' '.join(str(x)for x in v)if isinstance(v,list)else str(v)
     # Every payload is traversed. Effects require a specific operation token, never task names.
     for kind,pattern,conf in patterns:
      matching=[line for line in payload.splitlines()if not line.strip().startswith(('#','echo ','printf ')) and re.search(pattern,line)]
      if matching:
       ids.append(add(r,t,kind,cite(sf,vnode),conf,step=name))
    desc=body.get('description','')
    if 'trusted artifact'in desc.lower():
     dm=mapping(ss).get('description');ids.append(add(r,t,'Declared Trusted Artifact '+('extraction interface'if 'extract'in desc.lower()else'creation interface'),cite(sf,dm),'Interface-supported','Image entrypoint is not retained; .skip-trusted-artifacts/no-op branches and empty source references constrain this interface.',name))
   boundary={'step_name':name,'image':st.get('image'),'command':st.get('command'),'args':st.get('args'),'script_parameterization':bool('$(params.'in st.get('script','')),'referenced_stepaction_boundaries':[{'source_file':h['source_file'],'image':h['stepaction_spec'].get('image'),'command':h['stepaction_spec'].get('command'),'args':h['stepaction_spec'].get('args'),'unknown':'Referenced source body retained; its executable image, sourced /utils.sh or other helper implementation and runtime state remain unresolved.'} for h in t.get('referenced_stepactions',[]) if h['step_ordinal']==i],'unknown':'Image/entrypoint/helper implementation, actual runtime parameter/state values and branch execution are not verified.'}
   boundaries.append(boundary)
  # Parameter descriptions are retained as interface evidence, not assumed effects of opaque helpers.
  desc=t['task_spec'].get('description','');dn=mapping(n).get('description')
  if dn and any(w in desc.lower()for w in ['virtual machine','data object','deprovision','deploy','creates a','extracts']):ids.append(add(r,t,'Declared Task interface',cite(f,dn),'Interface-supported','Implementation may be opaque; interface description does not prove full repair validity.'))
  ids.append(add(r,t,'Unknown runtime/helper boundary',cite(f,n),'Unknown','Full Task source retained; executable images, opaque scripts/modules, input identities and external API semantics were not executed or resolved.'))
  entry={'task_name':t['task_name'],'phase':t['phase'],'ordinal':t['ordinal'],'inspected_files':sorted(inspected),'inspected_step_count':len(t['task_spec'].get('steps',[])),'source_traversal':'All script/command/args fields, parameter/volume/workspace/result declarations, and referenced StepAction bodies traversed; conservative operation signatures plus relationship source inspection.','effect_ids':ids,'unresolved_boundaries':boundaries,'coverage_status':'source inspected; runtime effects may remain Unknown'};comp['task_occurrences'].append(entry);task_entries[(r['pipeline_id'],t['task_name'])]=entry
 coverage.append(comp)
# Structural result dataflow is retained even when semantic recovery obligation is Unknown.
relationships=[]
def graph(r):
 tasks=r['original_spec'].get('tasks',[]);names={x['name']for x in tasks};g={n:set()for n in names}
 for t in tasks:
  for d in t.get('runAfter',[]):
   if d in names:g[d].add(t['name'])
  for d,_ in re.findall(r'\$\(tasks\.([^.]+)\.results\.([^)]+)\)',json.dumps(t)):
   if d in names:g[d].add(t['name'])
 for k in names:
  for a in names:
   if k in g[a]:g[a]|=g[k]
 return g

def relation(r,a,b,kind,confidence,producer,consumer,identity,trigger,repair=None,visibility=None,assumptions=None):
 g=graph(r);ordinary={x['name']for x in r['original_spec'].get('tasks',[])}
 if a not in ordinary or b not in ordinary:express='Unknown / finally-phase relation'
 elif b in g.get(a,set()):express='producer earlier than consumer; backward membership can name producer'
 elif a in g.get(b,set()):express='producer later descendant of consumer; direct backward membership cannot name producer'
 else:express='producer parallel to consumer; backward membership can name producer'
 z={'relationship_id':'A-R'+str(len(relationships)+1).zfill(5),'pipeline_id':r['pipeline_id'],'producer':a,'consumer':b,'relationship_kind':kind,'confidence':confidence,'producer_evidence':producer,'consumer_evidence':consumer,'state_identity':identity,'binding_branch_assumptions':assumptions or 'Actual runtime values, branch execution and external service semantics are unverified.','conditional_trigger':trigger,'trigger_status':'source-derived hypothetical; no historical failure/state record','conditional_reuse_obligation':'The named prerequisite must be usable for the specified consumer invocation; full correct repair is not established.'if confidence!='Unknown'else'Unknown: structural dataflow alone does not establish an external-state reuse obligation.','source_supported_repair_candidate':repair,'repair_validity':'Unknown: necessary candidate only, not complete repair set','structural_visibility':visibility or'explicit task-result reference','expressibility':express,'actual_plan_warning_count':'not measured'};relationships.append(z);return z
for r in S:
 original=r['original_spec'].get('tasks',[])+r['original_spec'].get('finally',[]);byname={t['task_name']:t for t in r['resolved_tasks']}
 for t in original:
  matches=sorted(set(re.findall(r'\$\(tasks\.([^.]+)\.results\.([^)]+)\)',json.dumps(t))))
  groups=collections.defaultdict(list)
  for a,result in matches:groups[a].append(result)
  for a,results in groups.items():
   if a not in byname:continue
   pt=byname[a];f=pt.get('task_source_file')or r['composition_file'];pn=specnode(f,pt['task_spec']);pm=mapping(pn);pe=cite(f,pm.get('results',pn));ce=textcite(r['composition_file'],'$(tasks.'+a+'.results.'+results[0]+')')
   relation(r,a,t['name'],'Result-value dataflow; semantic recovery obligation unresolved','Unknown',pe,ce,'Result(s) '+', '.join(results),'If result or referred state changes/vanishes, downstream semantics require separate source/runtime evidence.',visibility='explicit task-result reference')
 # Conservative artifact prerequisite upgrade: both producer creation and consumer extraction interfaces plus explicit result source binding.
 for z in [x for x in relationships if x['pipeline_id']==r['pipeline_id']]:
  pt=byname[z['producer']];ct=byname[z['consumer']]
  creators=[h for h in pt.get('referenced_stepactions',[])if 'creates a trusted artifact'in h['stepaction_spec'].get('description','').lower()]
  extractors=[h for h in ct.get('referenced_stepactions',[])if 'extracts a trusted artifact'in h['stepaction_spec'].get('description','').lower()]
  boundparams=[x for x in next(t for t in original if t['name']==z['consumer']).get('params',[])if 'ARTIFACT'in x['name'].upper()and ('$(tasks.'+z['producer']+'.results.')in json.dumps(x.get('value'))]
  extractparams={x['value'] for h in extractors for x in ct['task_spec']['steps'][h['step_ordinal']].get('params',[]) if x['name']=='sourceDataArtifact'}
  boundparams=[x for x in boundparams if '$(params.'+x['name']+')' in extractparams]
  if creators and extractors and boundparams:
   h=creators[0];j=extractors[0];hn=specnode(h['source_file'],h['stepaction_spec']);jn=specnode(j['source_file'],j['stepaction_spec']);z.update(relationship_kind='Conditional Trusted Artifact availability prerequisite',confidence='Interface-supported',producer_evidence=cite(h['source_file'],mapping(hn)['description']),consumer_evidence=cite(j['source_file'],mapping(jn)['description']),binding_evidence=z['consumer_evidence'],state_identity=json.dumps(boundparams),binding_branch_assumptions='Nonempty artifact result is bound to the extractor; producer creation did not skip via .skip-trusted-artifacts; artifact is actually consumed. Image entrypoint implementation remains opaque.',conditional_trigger='The bound OCI artifact has expired, been removed, or is inaccessible when extraction is required.',conditional_reuse_obligation='Extraction requires the bound artifact to be usable; retained Task success and result strings alone do not reestablish remote availability.',source_supported_repair_candidate=z['producer'],repair_validity='Unknown: rerunning producer might create a new reference; consumer binding/state and every additional prerequisite must be rechecked.')
# Code bound SCRIPT inputs only where the retained Task explicitly executes $(params.SCRIPT).
for r in S:
 for t in r['resolved_tasks']:
  original=next(x for x in r['original_spec'].get('tasks',[])+r['original_spec'].get('finally',[])if x['name']==t['task_name'])
  injected={x['name']:x.get('value')for x in original.get('params',[])}
  if 'SCRIPT'in injected and any('$(params.SCRIPT)'in st.get('script','')for st in t['task_spec'].get('steps',[])):
   payload=str(injected['SCRIPT'])
   for kind,pattern,conf in patterns:
    if re.search(pattern,payload):
     c=textcite(r['composition_file'],next(line.strip()for line in payload.splitlines()if re.search(pattern,line)))
     eid=add(r,t,kind+' from explicit SCRIPT binding',c,conf,'Parameter SCRIPT is executed by retained Task; actual URL content, cluster identity and branch execution are unknown.')
     task_entries[(r['pipeline_id'],t['task_name'])]['effect_ids'].append(eid)
 # Shared checkout source relationships: actual file existence/content is a conditional prerequisite, not a proved complete repair.
 for pt in r['resolved_tasks']:
  if not any('/ko-app/git-init'in st.get('script','')for st in pt['task_spec'].get('steps',[])):continue
  porig=next(x for x in r['original_spec'].get('tasks',[])if x['name']==pt['task_name'])
  pw={x['workspace']for x in porig.get('workspaces',[])if x['name']=='output'}
  for ct in r['resolved_tasks']:
   if ct['task_name']==pt['task_name']:continue
   corig=next(x for x in r['original_spec'].get('tasks',[])+r['original_spec'].get('finally',[])if x['name']==ct['task_name'])
   shared=[x for x in corig.get('workspaces',[])if x['workspace']in pw and x['name']=='source']
   if not shared or '$(workspaces.source.path)'not in json.dumps(ct['task_spec']):continue
   pf=pt.get('task_source_file')or r['composition_file'];cf=ct.get('task_source_file')or r['composition_file'];pn=specnode(pf,pt['task_spec']);cn=specnode(cf,ct['task_spec'])
   relation(r,pt['task_name'],ct['task_name'],'Conditional checkout/filesystem input prerequisite','Interface-supported',cite(pf,mapping(pn)['steps']),cite(cf,mapping(cn)['steps']),'Shared pipeline Workspace '+shared[0]['workspace']+'; checkout/subdirectory and consumer path must coincide.','Files/repository under the bound source path are removed, replaced, or do not match the consumer requested revision/path.',pt['task_name'],'common Workspace binding','git-init invocation is opaque but its declared path/url/revision inputs and common Workspace source bindings are retained; consumer actually selects this path and requires corresponding files. A new clone may change branch identity; full repair is Unknown.')
 # Explicit OpenShift provision/test resource interface, with result-bound credential identity.
 if r['repo']=='openshift/konflux-tasks':
  pt=next(t for t in r['resolved_tasks']if t['task_name']=='provision-ephemeral-cluster');ct=next(t for t in r['resolved_tasks']if t['task_name']=='run-test')
  pf=pt['task_source_file'];cf=ct.get('task_source_file')or r['composition_file']
  relation(r,pt['task_name'],ct['task_name'],'Conditional credential/live-cluster availability prerequisite','Interface-supported',textcite(pf,'TP_CLUSTER_NAME=$(oc create'),cite(cf,mapping(specnode(cf,ct['task_spec']))['steps']),'Result-bound secretRef and its kubeconfig refer to the provisioned ephemeral cluster.','Bound Secret is absent/invalid or referenced cluster no longer accepts the credential.',pt['task_name'],'explicit task-result reference','Provisioning controller, Secret publication, network and live cluster state are opaque; recreate may issue a new reference and is not a verified complete repair.')
 # Across-task initialization/cleanup does not establish an invisible dependency merely because it shares an application name.
 if r['repo']=='kubevirt/kubevirt-tekton-tasks':
  importname='import-unattend-configmaps'if r['sample_order']==26 else'import-autounattend-configmaps'
  pt=next(t for t in r['resolved_tasks']if t['task_name']==importname);ct=next(t for t in r['resolved_tasks']if t['task_name']=='create-vm')
  relation(r,importname,'create-vm','Potential ConfigMap initialization prerequisite; identity unresolved','Unknown',textcite(r['composition_file'],'unattendXMLConfigMapsURL'if r['sample_order']==26 else'autounattendXMLConfigMapsURL'),textcite(r['composition_file'],'configMap:'),'Imported remote manifest contents are not retained; cannot prove they create the ConfigMap named by the VM manifest.','Hypothetical removal/replacement of the named ConfigMap before VM creation.',None,'external state without either','The tasks have no result or Workspace binding for this ConfigMap dependency. Actual remote manifest membership and API resource semantics are Unknown; no positive initialization/recovery dependency counted.')
 if r['sample_order']==38:
  relation(r,'app-deploy','deploy-istio-service','Potential deployed-service routing prerequisite; manifest identity unresolved','Unknown',textcite(r['composition_file'],'apply'),textcite(next(t['task_source_file']for t in r['resolved_tasks']if t['task_name']=='deploy-istio-service'),'host: myapp'),'Istio script routes to myapp subsets v1/v2; app-deploy input manifests are not retained.','Hypothetical missing service/deployment/subset; correspondence to app-deploy is not established.',None,'external state without either','Different Workspace names and no Task result connect the route to app-deploy. Cannot establish producer resource identity from missing manifest content.')

for n,data in [('coverage.json',coverage),('effects.json',effects),('relationships.json',relationships)]: (O/n).write_text(json.dumps(data,indent=2))
summary={'coder':'automated source coder A','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'protocol_sha256':hashlib.sha256(pathlib.Path('/tmp/tekton-static-coding-protocol.md').read_bytes()).hexdigest(),'frozen_selected_index_sha256':hashlib.sha256((P/'selected-compositions.json').read_bytes()).hexdigest(),'compositions_inspected':len(coverage),'task_occurrences_inspected':sum(len(x['task_occurrences'])for x in coverage),'unique_task_body_source_files':111,'source_files_traversed':len(cache),'effect_records':len(effects),'effects_by_confidence':dict(collections.Counter(x['confidence']for x in effects)),'effects_by_class':dict(collections.Counter(x['effect_or_precondition']for x in effects)),'relationship_records':len(relationships),'relationships_by_confidence':dict(collections.Counter(x['confidence']for x in relationships)),'supported_relationship_compositions':len({x['pipeline_id']for x in relationships if x['confidence']!='Unknown'}),'relationship_unknown_compositions':len({x['pipeline_id']for x in relationships if x['confidence']=='Unknown'}),'composition_repo_counts':dict(collections.Counter(x['repo']for x in coverage)),'relationships_by_visibility':dict(collections.Counter(x['structural_visibility']for x in relationships)),'relationships_by_expressibility':dict(collections.Counter(x['expressibility']for x in relationships))}
(O/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))

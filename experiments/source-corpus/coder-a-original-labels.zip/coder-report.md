# Automated source coder A: original labels

## Scope and provenance

This is the original, unadjudicated coding of all 39 frozen composition bodies and all 391 ordinary/finally Task occurrences, including 32 finally Tasks. The prospective protocol is https://artifacts.internalmeta.com/a/1835202037493026 and the frozen packet is https://artifacts.internalmeta.com/a/2515033349270286. No other coder's labels were consulted. This coder shares model/system provenance and inherited parent context, including manuscript examples and project affiliation. It is not fully blinded to the manuscript or independent of the project, and it is not a human participant.

The corpus contains 24 release-service compositions, one integration composition, two KubeVirt compositions, three related OpenShift ephemeral-cluster profiles, and nine Catalog compositions. They are distinct source bodies, not 39 independent deployments or randomly sampled incidents. Shared Tasks and closely related release workflows make record counts highly dependent.

## Method and coverage

coverage.json enumerates every ordinary/finally Task occurrence, inspected source files, step counts, and runtime/helper boundaries. All script/command/args fields and Task declarations were traversed, with referenced StepAction bodies inspected once per distinct source and mapped back to each occurrence. The implementation retained 111 distinct Task source files and traversed 146 unique source files in total, including helper and composition citations.

Conservative operation signatures identify explicit command requests, file initialization/removal/guards and result writes. Description-backed artifact and Task operations are Interface-supported, not proofs of executable image behavior. Explicit bound SCRIPT inputs are coded only when the retained Task executes that parameter. Unknown is retained for each Task's executable images, modules, sourced helper functions, actual branch execution and external state semantics. Rule signatures are not a complete shell/Python semantic analysis; operations not captured by these signatures remain within the Unknown boundary. The source-inspection code is retained for audit.

Relationships begin with explicit result-value dataflow, whose semantic recovery obligation is Unknown until both producer and consumer interfaces support it. Trusted Artifact relationships require a producer creation interface, a consumer extraction interface, a pipeline result binding, and an exact sourceDataArtifact parameter binding to the extractor. Three initial apparent artifact matches that only passed artifact-directory path parameters were excluded from that upgrade before publication. Checkout relationships require explicit git-init path invocation and a corresponding consumer source Workspace path binding. OpenShift relationships require provisioned cluster identity and result-bound credential consumption. Source quotes and line spans were checked against the frozen raw files for every effect and relationship citation.

## Descriptive results

All 39 compositions contain at least one Source-explicit or Interface-supported effect/precondition record, and all 39 retain Unknown runtime boundaries. There are 1,096 occurrence-level records: 221 Source-explicit command/interface operations, 484 Interface-supported records, and 391 Unknown Task boundaries. These are labels, not counts of independently established runtime effects or incidents.

There are 629 relationship records: 208 Interface-supported conditional prerequisites and 421 Unknown semantic relationships. Source-supported prerequisites occur in 32 of 39 compositions: 22 related release-service compositions, seven Catalog compositions, and the three related OpenShift profiles. Thirty-one compositions also contain relationship records with Unknown semantics; these categories overlap, and unresolved completeness applies to the entire corpus.

Among the 208 supported relationships, 197 concern Trusted Artifact extraction after creation, eight concern checkout/filesystem inputs, and three concern credential/live-cluster availability. Structural visibility is an explicit Task result for 200 and a common Workspace binding for eight. None of the supported relationships is classified as external state without either structural link. This coding therefore supplies no positive evidence of an additional dependency lacking both Task-result and Workspace bindings.

Three candidate relationships lack either link but remain Unknown: ConfigMap import versus VM creation in each Windows pipeline, and application deployment versus Istio routing. Remote imported manifests and deployment manifests are not retained in the frozen packet, so resource-name correspondence cannot be established. They are not counted as supported invisible dependencies. A task name or shared application description does not resolve this gap.

For the supported relationships, 206 producers are earlier than the consumer in the graph formed by runAfter plus result references; backward membership can name them. Two concern finally-phase artifact consumption, with expressibility marked Unknown. No supported repair candidate is a later descendant of its consumer. This does not establish that all recovery obligations are backward-expressible: opaque effects and complete correct repair remain unresolved.

## Conditional interpretation and negative findings

Artifact references can remain syntactically present while the bound remote artifact expires, is deleted, or becomes inaccessible. This is a source-derived hypothetical availability prerequisite. Creating an artifact may be skipped via .skip-trusted-artifacts, and empty references may be no-ops. Image entrypoints are opaque. Rerunning a producer is only a conditional candidate: a new reference and downstream bindings need rechecking, and missing credentials or other external prerequisites may not be repaired.

A shared checkout can be removed or replaced while its producer's previous success is retained. Consumer path and revision identity must still coincide. These conditions are already exposed by the Workspace binding in the coded compositions; neither correct retry behavior nor operator value follows from them.

The OpenShift profiles consume result-bound kubeconfig/credential state and call oc against a live cluster. Reprovisioning may change both credentials and cluster identity; these labels do not prove that reprovisioning is sufficient or that a recorded failure occurred. Related provisioning profiles count as one application family for any discussion of independence.

Local prepare/mkdir/copy steps, checkout cleanup and trap-based temporary-file cleanup remain within a Task. Whole-Task retry already repeats a reached intra-Task initialization branch. Finally-phase cleanup is explicitly covered, and its occurrence is not evidence that every cleanup operation needs an extra retry dependency. The task bodies and interfaces may contain unverified runtime incompatibilities; source-body resolution is not a successful execution claim.

## Claim limits

No planner input/output was executed or retained by this coding, so actual zero-warning claims are unsupported. No workload, project tests, production operation, historic incident, human study, operator time/error, complete correct repair, benefit over an equally informed manual or persisted rule, or acceptance verdict was measured. Counts describe this frozen convenience corpus and the limits of this source coding. Difficult and negative cases remain in the original labels for source-based adjudication.
